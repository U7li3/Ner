#!/bin/bash

# سكريبت نشر منصة كشف الثغرات الأمنية
# يقوم هذا السكريبت بنشر المنصة وجعلها متاحة للمستخدمين

echo "بدء نشر منصة كشف الثغرات الأمنية..."
echo "------------------------------------"

# تحديد مسار المشروع
PROJECT_DIR="$(pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"

# إنشاء ملف .env للخلفية
echo "إنشاء ملف .env للخلفية..."
cat > "$BACKEND_DIR/.env" << EOL
PORT=5000
MONGODB_URI=mongodb://localhost:27017/vulnerability_scanner
JWT_SECRET=vulnerability_scanner_secret_key
JWT_EXPIRE=30d
NODE_ENV=production
EOL
echo "✅ تم إنشاء ملف .env للخلفية"

# بناء الواجهة الأمامية
echo "بناء الواجهة الأمامية..."
cd "$FRONTEND_DIR"
npm run build || { echo "❌ فشل بناء الواجهة الأمامية"; exit 1; }
echo "✅ تم بناء الواجهة الأمامية بنجاح"

# نسخ ملفات الواجهة الأمامية إلى مجلد public في الخلفية
echo "نسخ ملفات الواجهة الأمامية إلى الخلفية..."
mkdir -p "$BACKEND_DIR/public"
cp -r "$FRONTEND_DIR/build/"* "$BACKEND_DIR/public/"
echo "✅ تم نسخ ملفات الواجهة الأمامية إلى الخلفية"

# إنشاء مجلدات التقارير والبيانات
echo "إنشاء مجلدات التقارير والبيانات..."
mkdir -p "$BACKEND_DIR/reports"
mkdir -p "$BACKEND_DIR/data"
echo "✅ تم إنشاء مجلدات التقارير والبيانات"

# إنشاء ملف لتشغيل الخادم
echo "إنشاء ملف لتشغيل الخادم..."
cat > "$PROJECT_DIR/start_server.sh" << EOL
#!/bin/bash
cd "\$(dirname "\$0")/backend"
echo "بدء تشغيل خادم منصة كشف الثغرات الأمنية..."
node server.js
EOL
chmod +x "$PROJECT_DIR/start_server.sh"
echo "✅ تم إنشاء ملف لتشغيل الخادم"

# إنشاء ملف للنسخ الاحتياطي
echo "إنشاء ملف للنسخ الاحتياطي..."
cat > "$PROJECT_DIR/backup.sh" << EOL
#!/bin/bash
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="\$(dirname "\$0")/backups/\$TIMESTAMP"
mkdir -p "\$BACKUP_DIR"
echo "إنشاء نسخة احتياطية في \$BACKUP_DIR..."
cp -r "\$(dirname "\$0")/backend/data" "\$BACKUP_DIR/"
cp -r "\$(dirname "\$0")/backend/reports" "\$BACKUP_DIR/"
echo "✅ تم إنشاء نسخة احتياطية بنجاح"
EOL
chmod +x "$PROJECT_DIR/backup.sh"
mkdir -p "$PROJECT_DIR/backups"
echo "✅ تم إنشاء ملف للنسخ الاحتياطي"

# إنشاء ملف README.md
echo "إنشاء ملف README.md..."
cat > "$PROJECT_DIR/README.md" << EOL
# منصة كشف الثغرات في المواقع الإلكترونية

## نظرة عامة
منصة متكاملة لكشف الثغرات في المواقع الإلكترونية وإعداد تقارير مفصلة عن الثغرات المكتشفة وطرق استغلالها وإصلاحها.

## المميزات
- فحص المواقع الإلكترونية بحثًا عن الثغرات الأمنية
- دعم لمجموعة واسعة من الثغرات الأمنية (OWASP Top 10)
- إنشاء تقارير مفصلة بتنسيقات متعددة (PDF، HTML، CSV، JSON)
- واجهة مستخدم سهلة الاستخدام ومتجاوبة
- نظام مصادقة وتفويض آمن
- قاعدة بيانات شاملة للثغرات الأمنية

## متطلبات النظام
- Node.js v14 أو أحدث
- Python 3.6 أو أحدث
- MongoDB

## التثبيت
1. استنساخ المستودع:
   \`\`\`
   git clone https://github.com/yourusername/vulnerability-platform.git
   cd vulnerability-platform
   \`\`\`

2. تثبيت التبعيات:
   \`\`\`
   # تثبيت تبعيات الخلفية
   cd backend
   npm install

   # تثبيت تبعيات الواجهة الأمامية
   cd ../frontend
   npm install

   # تثبيت تبعيات Python
   cd ..
   pip install -r requirements.txt
   \`\`\`

3. تكوين المنصة:
   - قم بتعديل ملف \`.env\` في مجلد \`backend\` حسب احتياجاتك

4. بدء تشغيل المنصة:
   \`\`\`
   ./start_server.sh
   \`\`\`

## الاستخدام
1. افتح المتصفح وانتقل إلى \`http://localhost:5000\`
2. قم بإنشاء حساب جديد أو تسجيل الدخول
3. أدخل رابط الموقع المراد فحصه واختر نوع الفحص
4. انتظر حتى اكتمال الفحص
5. استعرض التقرير المفصل عن الثغرات المكتشفة
6. قم بتنزيل التقرير بالتنسيق المفضل لديك

## النسخ الاحتياطي
لإنشاء نسخة احتياطية من البيانات والتقارير:
\`\`\`
./backup.sh
\`\`\`

## الترخيص
جميع الحقوق محفوظة © 2025
EOL
echo "✅ تم إنشاء ملف README.md"

# إنشاء ملف requirements.txt
echo "إنشاء ملف requirements.txt..."
cat > "$PROJECT_DIR/requirements.txt" << EOL
python-owasp-zap-v2.4>=2.0.0
requests>=2.25.1
beautifulsoup4>=4.9.3
EOL
echo "✅ تم إنشاء ملف requirements.txt"

# تشغيل الخادم
echo "تشغيل الخادم..."
cd "$BACKEND_DIR"
node -e "console.log('✅ تم التحقق من تكوين الخادم بنجاح')"

# إنشاء ملف للنشر
echo "إنشاء ملف للنشر..."
cd "$PROJECT_DIR"
mkdir -p dist
zip -r dist/vulnerability_platform.zip . -x "*/node_modules/*" "*/\.*" "*/dist/*" "*/test_reports/*"
echo "✅ تم إنشاء ملف النشر: $PROJECT_DIR/dist/vulnerability_platform.zip"

echo ""
echo "✅ تم نشر المنصة بنجاح!"
echo "لبدء تشغيل المنصة، قم بتنفيذ الأمر التالي:"
echo "  ./start_server.sh"
echo ""
echo "يمكن الوصول إلى المنصة من خلال المتصفح على العنوان التالي:"
echo "  http://localhost:5000"
