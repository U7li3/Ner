#!/bin/bash
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$(dirname "$0")/backups/$TIMESTAMP"
mkdir -p "$BACKUP_DIR"
echo "إنشاء نسخة احتياطية في $BACKUP_DIR..."
cp -r "$(dirname "$0")/backend/data" "$BACKUP_DIR/"
cp -r "$(dirname "$0")/backend/reports" "$BACKUP_DIR/"
echo "✅ تم إنشاء نسخة احتياطية بنجاح"
