# تصميم قاعدة البيانات لمنصة كشف الثغرات الأمنية

## نظرة عامة

تستخدم منصة كشف الثغرات الأمنية قاعدة بيانات MongoDB، وهي قاعدة بيانات NoSQL مرنة تسمح بتخزين البيانات في شكل وثائق JSON. تم اختيار MongoDB لقدرتها على التعامل مع البيانات غير المهيكلة والمرونة في تطوير المخططات مع تطور المنصة.

## مخطط قاعدة البيانات

### مجموعة المستخدمين (users)

```json
{
  "_id": ObjectId("..."),
  "username": "user123",
  "email": "user@example.com",
  "password": "$2b$10$...", // كلمة المرور المشفرة
  "firstName": "محمد",
  "lastName": "أحمد",
  "role": "user", // admin, user
  "isVerified": true,
  "verificationToken": "...",
  "resetPasswordToken": "...",
  "resetPasswordExpires": ISODate("..."),
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("..."),
  "lastLogin": ISODate("..."),
  "settings": {
    "notifications": {
      "email": true,
      "browser": true
    },
    "theme": "light",
    "language": "ar"
  }
}
```

### مجموعة عمليات الفحص (scans)

```json
{
  "_id": ObjectId("..."),
  "userId": ObjectId("..."), // مرجع للمستخدم
  "targetUrl": "https://example.com",
  "scanType": "comprehensive", // quick, comprehensive, custom
  "status": "completed", // pending, in_progress, completed, failed
  "startTime": ISODate("..."),
  "endTime": ISODate("..."),
  "progress": 100, // نسبة مئوية
  "configuration": {
    "tools": ["owasp-zap", "sqlmap", "nikto"],
    "depth": 3,
    "scope": "full", // full, specific_paths
    "excludedPaths": ["/admin", "/api/private"],
    "authentication": {
      "required": false,
      "type": "form", // form, basic, oauth
      "credentials": {
        "username": "...",
        "password": "..."
      }
    }
  },
  "summary": {
    "totalVulnerabilities": 12,
    "criticalCount": 2,
    "highCount": 3,
    "mediumCount": 4,
    "lowCount": 3,
    "infoCount": 0
  },
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("...")
}
```

### مجموعة الثغرات المكتشفة (discovered_vulnerabilities)

```json
{
  "_id": ObjectId("..."),
  "scanId": ObjectId("..."), // مرجع لعملية الفحص
  "vulnerabilityType": "sql_injection",
  "name": "SQL Injection in Login Form",
  "description": "تم اكتشاف ثغرة حقن SQL في نموذج تسجيل الدخول",
  "severity": "high", // critical, high, medium, low, info
  "cvssScore": 8.5,
  "location": {
    "url": "https://example.com/login",
    "parameter": "username",
    "method": "POST"
  },
  "evidence": {
    "request": "POST /login HTTP/1.1\nHost: example.com\n...",
    "response": "HTTP/1.1 200 OK\n...",
    "payload": "' OR 1=1 --"
  },
  "remediation": {
    "description": "استخدم الاستعلامات المعدة مسبقًا وتصفية المدخلات بشكل صحيح",
    "code": "// مثال للكود الآمن\nconst query = 'SELECT * FROM users WHERE username = ? AND password = ?';\ndb.execute(query, [username, password]);"
  },
  "references": [
    {
      "title": "OWASP SQL Injection",
      "url": "https://owasp.org/www-community/attacks/SQL_Injection"
    }
  ],
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("...")
}
```

### مجموعة قاعدة بيانات الثغرات (vulnerabilities)

```json
{
  "_id": ObjectId("..."),
  "name": "SQL Injection",
  "description": "ثغرة حقن SQL تسمح للمهاجمين بحقن أوامر SQL ضارة في قاعدة البيانات",
  "severity": "high",
  "category": "injection",
  "cweId": "CWE-89",
  "remediation": "استخدام الاستعلامات المعدة مسبقًا وتصفية المدخلات بشكل صحيح",
  "detectionMethods": [
    {
      "tool": "owasp-zap",
      "pattern": "...",
      "confidence": "high"
    },
    {
      "tool": "sqlmap",
      "pattern": "...",
      "confidence": "high"
    }
  ],
  "references": [
    {
      "title": "OWASP SQL Injection",
      "url": "https://owasp.org/www-community/attacks/SQL_Injection"
    },
    {
      "title": "MITRE CWE-89",
      "url": "https://cwe.mitre.org/data/definitions/89.html"
    }
  ],
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("...")
}
```

### مجموعة سجلات الفحص (scan_logs)

```json
{
  "_id": ObjectId("..."),
  "scanId": ObjectId("..."), // مرجع لعملية الفحص
  "timestamp": ISODate("..."),
  "level": "info", // debug, info, warning, error
  "message": "بدء فحص الموقع https://example.com",
  "source": "scanner", // scanner, system, user
  "details": {
    "tool": "owasp-zap",
    "action": "start_scan",
    "parameters": {
      "target": "https://example.com",
      "scanPolicy": "Default Policy"
    }
  }
}
```

### مجموعة التقارير (reports)

```json
{
  "_id": ObjectId("..."),
  "scanId": ObjectId("..."), // مرجع لعملية الفحص
  "userId": ObjectId("..."), // مرجع للمستخدم
  "name": "تقرير فحص example.com",
  "format": "pdf", // pdf, html, csv, json
  "generatedAt": ISODate("..."),
  "fileUrl": "/reports/123456789.pdf",
  "fileSize": 1024, // بالكيلوبايت
  "summary": {
    "targetUrl": "https://example.com",
    "scanDuration": 3600, // بالثواني
    "totalVulnerabilities": 12,
    "riskScore": 75, // درجة المخاطرة من 0 إلى 100
    "vulnerabilitiesBySeverity": {
      "critical": 2,
      "high": 3,
      "medium": 4,
      "low": 3,
      "info": 0
    }
  },
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("...")
}
```

### مجموعة الإشعارات (notifications)

```json
{
  "_id": ObjectId("..."),
  "userId": ObjectId("..."), // مرجع للمستخدم
  "type": "scan_completed", // scan_completed, vulnerability_found, system_alert
  "title": "اكتمال عملية الفحص",
  "message": "تم اكتمال فحص الموقع https://example.com بنجاح",
  "read": false,
  "data": {
    "scanId": ObjectId("..."),
    "reportId": ObjectId("...")
  },
  "createdAt": ISODate("..."),
  "updatedAt": ISODate("...")
}
```

## العلاقات بين المجموعات

1. **المستخدمون والفحوصات**: علاقة واحد إلى متعدد (مستخدم واحد يمكنه إجراء عدة عمليات فحص)
2. **الفحوصات والثغرات المكتشفة**: علاقة واحد إلى متعدد (عملية فحص واحدة يمكن أن تكتشف عدة ثغرات)
3. **الفحوصات والتقارير**: علاقة واحد إلى متعدد (عملية فحص واحدة يمكن أن تنتج عدة تقارير بصيغ مختلفة)
4. **الفحوصات وسجلات الفحص**: علاقة واحد إلى متعدد (عملية فحص واحدة تنتج عدة سجلات)
5. **المستخدمون والإشعارات**: علاقة واحد إلى متعدد (مستخدم واحد يمكن أن يتلقى عدة إشعارات)

## الفهارس (Indexes)

لتحسين أداء الاستعلامات، تم إنشاء الفهارس التالية:

1. `users.email`: فهرس فريد للبحث السريع عن المستخدمين بالبريد الإلكتروني
2. `scans.userId`: للبحث عن عمليات الفحص الخاصة بمستخدم معين
3. `scans.targetUrl`: للبحث عن عمليات الفحص لموقع معين
4. `discovered_vulnerabilities.scanId`: للبحث عن الثغرات المكتشفة في عملية فحص معينة
5. `scan_logs.scanId`: للبحث عن سجلات عملية فحص معينة
6. `reports.scanId`: للبحث عن التقارير الخاصة بعملية فحص معينة
7. `notifications.userId`: للبحث عن الإشعارات الخاصة بمستخدم معين

## اعتبارات الأمان

1. **تشفير البيانات الحساسة**: يتم تشفير كلمات المرور باستخدام خوارزمية bcrypt
2. **فصل البيانات**: يتم فصل بيانات المستخدمين عن بعضها البعض باستخدام حقل userId
3. **التحكم في الوصول**: يتم التحقق من صلاحيات المستخدم قبل السماح بالوصول إلى البيانات
4. **سجلات التدقيق**: يتم تسجيل جميع العمليات المهمة في سجلات الفحص

## استراتيجية النسخ الاحتياطي

1. **النسخ الاحتياطي اليومي**: يتم إجراء نسخ احتياطي كامل لقاعدة البيانات يوميًا
2. **النسخ الاحتياطي التزايدي**: يتم إجراء نسخ احتياطي تزايدي كل ساعة
3. **الاحتفاظ بالنسخ**: يتم الاحتفاظ بالنسخ الاحتياطية لمدة 30 يومًا

## قابلية التوسع

1. **التجزئة (Sharding)**: يمكن تجزئة المجموعات الكبيرة مثل discovered_vulnerabilities وscan_logs لتحسين الأداء
2. **التكرار (Replication)**: يمكن إعداد مجموعة تكرار MongoDB لضمان توافر البيانات
3. **التخزين المؤقت (Caching)**: يمكن استخدام Redis لتخزين البيانات المستخدمة بشكل متكرر مؤقتًا
