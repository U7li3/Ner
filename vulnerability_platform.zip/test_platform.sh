#!/bin/bash

# سكريبت اختبار منصة كشف الثغرات الأمنية
# يقوم هذا السكريبت باختبار مختلف مكونات المنصة للتأكد من عملها بشكل صحيح

echo "بدء اختبار منصة كشف الثغرات الأمنية..."
echo "----------------------------------------"

# إنشاء دليل للاختبارات
TEST_DIR="$(pwd)/test_results"
mkdir -p $TEST_DIR

# تحديد مسار المشروع
PROJECT_DIR="$(pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"

# اختبار وجود الملفات الأساسية
echo "اختبار وجود الملفات الأساسية..."
MISSING_FILES=0

check_file() {
  if [ -f "$1" ]; then
    echo "✅ الملف موجود: $1"
  else
    echo "❌ الملف غير موجود: $1"
    MISSING_FILES=$((MISSING_FILES+1))
  fi
}

check_directory() {
  if [ -d "$1" ]; then
    echo "✅ المجلد موجود: $1"
  else
    echo "❌ المجلد غير موجود: $1"
    MISSING_FILES=$((MISSING_FILES+1))
  fi
}

# التحقق من ملفات الخلفية
check_file "$BACKEND_DIR/server.js"
check_file "$BACKEND_DIR/routes/auth.js"
check_file "$BACKEND_DIR/routes/scan.js"
check_file "$BACKEND_DIR/routes/report.js"
check_file "$BACKEND_DIR/models/User.js"
check_file "$BACKEND_DIR/models/Scan.js"
check_file "$BACKEND_DIR/models/Vulnerability.js"
check_file "$BACKEND_DIR/utils/ReportGenerator.js"
check_file "$BACKEND_DIR/scanners/zap_scanner.py"
check_file "$BACKEND_DIR/scanners/sqlmap_scanner.py"
check_file "$BACKEND_DIR/scanners/scan_manager.py"

# التحقق من ملفات الواجهة الأمامية
check_file "$FRONTEND_DIR/src/index.js"
check_file "$FRONTEND_DIR/src/App.js"
check_file "$FRONTEND_DIR/src/components/layout/Navbar.js"
check_file "$FRONTEND_DIR/src/pages/HomePage.js"
check_file "$FRONTEND_DIR/src/pages/NewScanPage.js"
check_file "$FRONTEND_DIR/src/pages/ScanDetailsPage.js"

# التحقق من قاعدة بيانات الثغرات
check_file "$BACKEND_DIR/data/vulnerabilities.json"

echo ""
if [ $MISSING_FILES -eq 0 ]; then
  echo "✅ جميع الملفات الأساسية موجودة"
else
  echo "❌ هناك $MISSING_FILES ملفات مفقودة"
fi

# اختبار تثبيت التبعيات
echo ""
echo "اختبار تثبيت التبعيات..."

check_dependency() {
  if npm list --prefix "$1" | grep -q "$2"; then
    echo "✅ التبعية مثبتة: $2"
  else
    echo "❌ التبعية غير مثبتة: $2"
  fi
}

# التحقق من تبعيات الخلفية
check_dependency "$BACKEND_DIR" "express"
check_dependency "$BACKEND_DIR" "mongoose"
check_dependency "$BACKEND_DIR" "jsonwebtoken"
check_dependency "$BACKEND_DIR" "bcrypt"
check_dependency "$BACKEND_DIR" "cors"
check_dependency "$BACKEND_DIR" "pdfkit"
check_dependency "$BACKEND_DIR" "csv-writer"

# التحقق من تبعيات الواجهة الأمامية
check_dependency "$FRONTEND_DIR" "react"
check_dependency "$FRONTEND_DIR" "react-dom"
check_dependency "$FRONTEND_DIR" "react-router-dom"
check_dependency "$FRONTEND_DIR" "@mui/material"
check_dependency "$FRONTEND_DIR" "@emotion/react"

# اختبار إنشاء تقرير نموذجي
echo ""
echo "اختبار إنشاء تقرير نموذجي..."

cd "$BACKEND_DIR"

# إنشاء سكريبت اختبار مؤقت
cat > test_report_generator.js << 'EOL'
const ReportGenerator = require('./utils/ReportGenerator');
const fs = require('fs');
const path = require('path');

async function testReportGenerator() {
  try {
    // قراءة بيانات الثغرات من ملف JSON
    const vulnerabilitiesPath = path.join(__dirname, 'data', 'vulnerabilities.json');
    let vulnerabilities = [];
    
    if (fs.existsSync(vulnerabilitiesPath)) {
      vulnerabilities = JSON.parse(fs.readFileSync(vulnerabilitiesPath, 'utf8'));
      console.log(`✅ تم قراءة ${vulnerabilities.length} ثغرة من ملف البيانات`);
    } else {
      console.log('❌ ملف بيانات الثغرات غير موجود، استخدام بيانات نموذجية');
      vulnerabilities = [
        {
          name: 'SQL Injection',
          description: 'ثغرة حقن SQL في نموذج تسجيل الدخول',
          severity: 'critical',
          category: 'injection',
          remediation: 'استخدام الاستعلامات المعدة مسبقًا'
        },
        {
          name: 'Cross-Site Scripting (XSS)',
          description: 'ثغرة XSS في صفحة البحث',
          severity: 'high',
          category: 'xss',
          remediation: 'ترميز مخرجات HTML'
        }
      ];
    }
    
    // بيانات فحص نموذجية
    const scanData = {
      id: 'test-scan-001',
      targetUrl: 'https://example.com',
      scanType: 'comprehensive',
      startTime: new Date(Date.now() - 3600000), // قبل ساعة
      endTime: new Date(),
      status: 'completed'
    };
    
    // إنشاء مولد التقارير
    const reportGenerator = new ReportGenerator({
      outputDir: path.join(__dirname, 'test_reports')
    });
    
    // إنشاء التقارير
    console.log('إنشاء تقرير PDF...');
    const pdfPath = await reportGenerator.generatePdfReport(scanData, vulnerabilities);
    console.log(`✅ تم إنشاء تقرير PDF: ${pdfPath}`);
    
    console.log('إنشاء تقرير HTML...');
    const htmlPath = await reportGenerator.generateHtmlReport(scanData, vulnerabilities);
    console.log(`✅ تم إنشاء تقرير HTML: ${htmlPath}`);
    
    console.log('إنشاء تقرير CSV...');
    const csvPath = await reportGenerator.generateCsvReport(scanData, vulnerabilities);
    console.log(`✅ تم إنشاء تقرير CSV: ${csvPath}`);
    
    console.log('إنشاء تقرير JSON...');
    const jsonPath = await reportGenerator.generateJsonReport(scanData, vulnerabilities);
    console.log(`✅ تم إنشاء تقرير JSON: ${jsonPath}`);
    
    return {
      success: true,
      reports: {
        pdf: pdfPath,
        html: htmlPath,
        csv: csvPath,
        json: jsonPath
      }
    };
  } catch (err) {
    console.error('❌ حدث خطأ أثناء اختبار مولد التقارير:', err);
    return {
      success: false,
      error: err.message
    };
  }
}

// تنفيذ الاختبار
testReportGenerator()
  .then(result => {
    if (result.success) {
      console.log('✅ تم اختبار مولد التقارير بنجاح');
      process.exit(0);
    } else {
      console.error('❌ فشل اختبار مولد التقارير');
      process.exit(1);
    }
  })
  .catch(err => {
    console.error('❌ حدث خطأ غير متوقع:', err);
    process.exit(1);
  });
EOL

# تنفيذ اختبار مولد التقارير
echo "تنفيذ اختبار مولد التقارير..."
node test_report_generator.js
REPORT_TEST_RESULT=$?

if [ $REPORT_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار مولد التقارير ناجح"
else
  echo "❌ فشل اختبار مولد التقارير"
fi

# اختبار وحدات فحص الثغرات
echo ""
echo "اختبار وحدات فحص الثغرات..."

# إنشاء سكريبت اختبار مؤقت لوحدة ZAP
cat > test_zap_scanner.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import json

# إضافة مسار المشروع إلى مسار البحث
sys.path.append(os.path.join(os.path.dirname(__file__), 'scanners'))

try:
    from zap_scanner import ZapScanner
    print("✅ تم استيراد وحدة ZapScanner بنجاح")
    
    # إنشاء فاحص ZAP
    scanner = ZapScanner('https://example.com', 'quick')
    print("✅ تم إنشاء فاحص ZAP بنجاح")
    
    # محاكاة الاتصال بخادم ZAP
    if scanner.connect_to_zap():
        print("✅ تم محاكاة الاتصال بخادم ZAP بنجاح")
    else:
        print("❌ فشل محاكاة الاتصال بخادم ZAP")
        sys.exit(1)
    
    # محاكاة بدء الفحص
    if scanner.start_scan():
        print("✅ تم محاكاة بدء الفحص بنجاح")
    else:
        print("❌ فشل محاكاة بدء الفحص")
        sys.exit(1)
    
    # محاكاة الحصول على حالة الفحص
    status = scanner.get_scan_status()
    if status and 'status' in status:
        print(f"✅ تم الحصول على حالة الفحص: {status['status']}")
    else:
        print("❌ فشل الحصول على حالة الفحص")
        sys.exit(1)
    
    # محاكاة الحصول على نتائج الفحص
    results = scanner.get_scan_results()
    if results and 'vulnerabilities' in results:
        print(f"✅ تم الحصول على نتائج الفحص: {len(results['vulnerabilities'])} ثغرة")
    else:
        print("❌ فشل الحصول على نتائج الفحص")
        sys.exit(1)
    
    # محاكاة حفظ النتائج إلى ملف
    output_file = os.path.join(os.path.dirname(__file__), 'test_reports', 'zap_test_results.json')
    if scanner.save_results_to_file(output_file):
        print(f"✅ تم حفظ نتائج الفحص إلى: {output_file}")
    else:
        print("❌ فشل حفظ نتائج الفحص")
        sys.exit(1)
    
    # محاكاة إيقاف الفحص
    if scanner.stop_scan():
        print("✅ تم محاكاة إيقاف الفحص بنجاح")
    else:
        print("❌ فشل محاكاة إيقاف الفحص")
        sys.exit(1)
    
    print("✅ اختبار وحدة ZapScanner ناجح")
    sys.exit(0)
except Exception as e:
    print(f"❌ حدث خطأ أثناء اختبار وحدة ZapScanner: {str(e)}")
    sys.exit(1)
EOL

# تنفيذ اختبار وحدة ZAP
echo "تنفيذ اختبار وحدة ZAP..."
mkdir -p test_reports
python3 test_zap_scanner.py
ZAP_TEST_RESULT=$?

if [ $ZAP_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار وحدة ZAP ناجح"
else
  echo "❌ فشل اختبار وحدة ZAP"
fi

# إنشاء سكريبت اختبار مؤقت لوحدة SQLMap
cat > test_sqlmap_scanner.py << 'EOL'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import json

# إضافة مسار المشروع إلى مسار البحث
sys.path.append(os.path.join(os.path.dirname(__file__), 'scanners'))

try:
    from sqlmap_scanner import SqlmapScanner
    print("✅ تم استيراد وحدة SqlmapScanner بنجاح")
    
    # إنشاء فاحص SQLMap
    scanner = SqlmapScanner('https://example.com', 'quick')
    print("✅ تم إنشاء فاحص SQLMap بنجاح")
    
    # محاكاة بدء الفحص
    if scanner.start_scan():
        print("✅ تم محاكاة بدء الفحص بنجاح")
    else:
        print("❌ فشل محاكاة بدء الفحص")
        sys.exit(1)
    
    # محاكاة الحصول على حالة الفحص
    status = scanner.get_scan_status()
    if status and 'status' in status:
        print(f"✅ تم الحصول على حالة الفحص: {status['status']}")
    else:
        print("❌ فشل الحصول على حالة الفحص")
        sys.exit(1)
    
    # محاكاة الحصول على نتائج الفحص
    results = scanner.get_scan_results()
    if results and 'vulnerabilities' in results:
        print(f"✅ تم الحصول على نتائج الفحص: {len(results['vulnerabilities'])} ثغرة")
    else:
        print("❌ فشل الحصول على نتائج الفحص")
        sys.exit(1)
    
    # محاكاة حفظ النتائج إلى ملف
    output_file = os.path.join(os.path.dirname(__file__), 'test_reports', 'sqlmap_test_results.json')
    if scanner.save_results_to_file(output_file):
        print(f"✅ تم حفظ نتائج الفحص إلى: {output_file}")
    else:
        print("❌ فشل حفظ نتائج الفحص")
        sys.exit(1)
    
    # محاكاة إيقاف الفحص
    if scanner.stop_scan():
        print("✅ تم محاكاة إيقاف الفحص بنجاح")
    else:
        print("❌ فشل محاكاة إيقاف الفحص")
        sys.exit(1)
    
    print("✅ اختبار وحدة SqlmapScanner ناجح")
    sys.exit(0)
except Exception as e:
    print(f"❌ حدث خطأ أثناء اختبار وحدة SqlmapScanner: {str(e)}")
    sys.exit(1)
EOL

# تنفيذ اختبار وحدة SQLMap
echo "تنفيذ اختبار وحدة SQLMap..."
python3 test_sqlmap_scanner.py
SQLMAP_TEST_RESULT=$?

if [ $SQLMAP_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار وحدة SQLMap ناجح"
else
  echo "❌ فشل اختبار وحدة SQLMap"
fi

# تلخيص نتائج الاختبارات
echo ""
echo "ملخص نتائج الاختبارات:"
echo "----------------------"

if [ $MISSING_FILES -eq 0 ]; then
  echo "✅ اختبار الملفات الأساسية: ناجح"
else
  echo "❌ اختبار الملفات الأساسية: فشل ($MISSING_FILES ملفات مفقودة)"
fi

if [ $REPORT_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار مولد التقارير: ناجح"
else
  echo "❌ اختبار مولد التقارير: فشل"
fi

if [ $ZAP_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار وحدة ZAP: ناجح"
else
  echo "❌ اختبار وحدة ZAP: فشل"
fi

if [ $SQLMAP_TEST_RESULT -eq 0 ]; then
  echo "✅ اختبار وحدة SQLMap: ناجح"
else
  echo "❌ اختبار وحدة SQLMap: فشل"
fi

# تحديد نتيجة الاختبار الإجمالية
if [ $MISSING_FILES -eq 0 ] && [ $REPORT_TEST_RESULT -eq 0 ] && [ $ZAP_TEST_RESULT -eq 0 ] && [ $SQLMAP_TEST_RESULT -eq 0 ]; then
  echo ""
  echo "✅ جميع الاختبارات ناجحة! المنصة جاهزة للنشر."
  TEST_RESULT=0
else
  echo ""
  echo "❌ بعض الاختبارات فشلت. يرجى إصلاح المشكلات قبل النشر."
  TEST_RESULT=1
fi

# تنظيف الملفات المؤقتة
rm -f test_report_generator.js test_zap_scanner.py test_sqlmap_scanner.py

exit $TEST_RESULT
