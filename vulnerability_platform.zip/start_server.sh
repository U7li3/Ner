#!/bin/bash
cd "$(dirname "$0")/backend"
echo "بدء تشغيل خادم منصة كشف الثغرات الأمنية..."
node server.js
