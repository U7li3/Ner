const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// مخطط عملية الفحص
const scanSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  targetUrl: {
    type: String,
    required: true,
    trim: true
  },
  scanType: {
    type: String,
    enum: ['quick', 'comprehensive', 'custom'],
    default: 'quick'
  },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed', 'failed'],
    default: 'pending'
  },
  startTime: {
    type: Date
  },
  endTime: {
    type: Date
  },
  progress: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  configuration: {
    tools: [{
      type: String,
      enum: ['owasp-zap', 'nikto', 'sqlmap', 'w3af']
    }],
    depth: {
      type: Number,
      min: 1,
      max: 3,
      default: 2
    },
    scope: {
      type: String,
      enum: ['full', 'specific_paths'],
      default: 'full'
    },
    excludedPaths: [String],
    authentication: {
      required: {
        type: Boolean,
        default: false
      },
      type: {
        type: String,
        enum: ['form', 'basic', 'oauth'],
        default: 'form'
      },
      credentials: {
        username: String,
        password: String
      }
    }
  },
  summary: {
    totalVulnerabilities: {
      type: Number,
      default: 0
    },
    criticalCount: {
      type: Number,
      default: 0
    },
    highCount: {
      type: Number,
      default: 0
    },
    mediumCount: {
      type: Number,
      default: 0
    },
    lowCount: {
      type: Number,
      default: 0
    },
    infoCount: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

const Scan = mongoose.model('Scan', scanSchema);

module.exports = Scan;
