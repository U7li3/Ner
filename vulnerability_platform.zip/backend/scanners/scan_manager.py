#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة إدارة فحص الثغرات الأمنية
"""

import sys
import os
import time
import json
import logging
import importlib
import threading
from datetime import datetime

# استيراد وحدات الفحص
from zap_scanner import ZapScanner
from sqlmap_scanner import SqlmapScanner

# إعداد التسجيل
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('scan_manager')

class ScanManager:
    """مدير فحص الثغرات الأمنية"""
    
    def __init__(self, scan_id, target_url, scan_type='quick', configuration=None):
        """
        تهيئة مدير الفحص
        
        المعلمات:
            scan_id (str): معرف عملية الفحص
            target_url (str): عنوان URL المستهدف للفحص
            scan_type (str): نوع الفحص ('quick', 'comprehensive', 'custom')
            configuration (dict): تكوين الفحص
        """
        self.scan_id = scan_id
        self.target_url = target_url
        self.scan_type = scan_type
        self.configuration = configuration or {}
        
        # تكوين أدوات الفحص
        self.tools = self.configuration.get('tools', [])
        if not self.tools:
            if scan_type == 'quick':
                self.tools = ['owasp-zap']
            elif scan_type == 'comprehensive':
                self.tools = ['owasp-zap', 'sqlmap']
            else:
                self.tools = ['owasp-zap']
        
        # حالة الفحص
        self.status = 'pending'
        self.progress = 0
        self.start_time = None
        self.end_time = None
        
        # نتائج الفحص
        self.results = {
            'vulnerabilities': []
        }
        
        # مسار حفظ النتائج
        self.results_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scan_results', scan_id)
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def start_scan(self):
        """
        بدء عملية الفحص
        
        العوائد:
            bool: نجاح بدء الفحص
        """
        try:
            logger.info(f'بدء عملية الفحص: {self.scan_id}')
            
            # تحديث حالة الفحص
            self.status = 'in_progress'
            self.start_time = datetime.now()
            self.progress = 0
            
            # بدء الفحص في خيط منفصل
            thread = threading.Thread(target=self._run_scan)
            thread.daemon = True
            thread.start()
            
            return True
        except Exception as e:
            logger.error(f'فشل بدء عملية الفحص: {str(e)}')
            self.status = 'failed'
            return False
    
    def _run_scan(self):
        """تنفيذ عملية الفحص"""
        try:
            # تنفيذ الفحص باستخدام كل أداة
            for tool in self.tools:
                self._run_tool_scan(tool)
                
            # دمج النتائج
            self._merge_results()
            
            # تحديث حالة الفحص
            self.status = 'completed'
            self.end_time = datetime.now()
            self.progress = 100
            
            logger.info(f'تم اكتمال عملية الفحص: {self.scan_id}')
        except Exception as e:
            logger.error(f'فشل تنفيذ عملية الفحص: {str(e)}')
            self.status = 'failed'
            self.end_time = datetime.now()
    
    def _run_tool_scan(self, tool):
        """
        تنفيذ الفحص باستخدام أداة محددة
        
        المعلمات:
            tool (str): اسم أداة الفحص
        """
        logger.info(f'بدء الفحص باستخدام {tool}')
        
        try:
            # تحديث التقدم
            self.progress += 10
            
            # تنفيذ الفحص حسب الأداة
            if tool == 'owasp-zap':
                scanner = ZapScanner(self.target_url, self.scan_type)
                scanner.connect_to_zap()
                scanner.start_scan()
                
                # انتظار اكتمال الفحص
                while True:
                    status = scanner.get_scan_status()
                    self.progress = min(45, 10 + int(status['progress'] * 0.35))
                    
                    if status['status'] == 'completed':
                        break
                    
                    time.sleep(1)
                
                # الحصول على النتائج
                results = scanner.get_scan_results()
                
                # حفظ النتائج
                output_file = os.path.join(self.results_dir, 'zap_results.json')
                scanner.save_results_to_file(output_file)
            
            elif tool == 'sqlmap':
                scanner = SqlmapScanner(self.target_url, self.scan_type)
                scanner.start_scan()
                
                # انتظار اكتمال الفحص
                while True:
                    status = scanner.get_scan_status()
                    self.progress = min(80, 45 + int(status['progress'] * 0.35))
                    
                    if status['status'] == 'completed':
                        break
                    
                    time.sleep(1)
                
                # الحصول على النتائج
                results = scanner.get_scan_results()
                
                # حفظ النتائج
                output_file = os.path.join(self.results_dir, 'sqlmap_results.json')
                scanner.save_results_to_file(output_file)
            
            logger.info(f'تم اكتمال الفحص باستخدام {tool}')
        except Exception as e:
            logger.error(f'فشل الفحص باستخدام {tool}: {str(e)}')
    
    def _merge_results(self):
        """دمج نتائج الفحص من جميع الأدوات"""
        try:
            logger.info('دمج نتائج الفحص')
            
            # قراءة نتائج ZAP
            zap_results_file = os.path.join(self.results_dir, 'zap_results.json')
            if os.path.exists(zap_results_file):
                with open(zap_results_file, 'r', encoding='utf-8') as f:
                    zap_results = json.load(f)
                    self.results['vulnerabilities'].extend(zap_results['vulnerabilities'])
            
            # قراءة نتائج SQLMap
            sqlmap_results_file = os.path.join(self.results_dir, 'sqlmap_results.json')
            if os.path.exists(sqlmap_results_file):
                with open(sqlmap_results_file, 'r', encoding='utf-8') as f:
                    sqlmap_results = json.load(f)
                    self.results['vulnerabilities'].extend(sqlmap_results['vulnerabilities'])
            
            # حفظ النتائج المدمجة
            output_file = os.path.join(self.results_dir, 'merged_results.json')
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(self.results, f, ensure_ascii=False, indent=2)
            
            logger.info(f'تم دمج نتائج الفحص وحفظها في {output_file}')
        except Exception as e:
            logger.error(f'فشل دمج نتائج الفحص: {str(e)}')
    
    def get_scan_status(self):
        """
        الحصول على حالة الفحص
        
        العوائد:
            dict: حالة الفحص
        """
        return {
            'status': self.status,
            'progress': self.progress,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None
        }
    
    def get_scan_results(self):
        """
        الحصول على نتائج الفحص
        
        العوائد:
            dict: نتائج الفحص
        """
        if self.status != 'completed':
            return {'vulnerabilities': []}
        
        return self.results
    
    def stop_scan(self):
        """
        إيقاف عملية الفحص
        
        العوائد:
            bool: نجاح إيقاف الفحص
        """
        try:
            logger.info(f'إيقاف عملية الفحص: {self.scan_id}')
            
            # تحديث حالة الفحص
            self.status = 'stopped'
            self.end_time = datetime.now()
            
            # في التطبيق الفعلي، يجب إيقاف جميع عمليات الفحص النشطة
            
            logger.info('تم إيقاف عملية الفحص بنجاح')
            return True
        except Exception as e:
            logger.error(f'فشل إيقاف عملية الفحص: {str(e)}')
            return False

def main():
    """الدالة الرئيسية"""
    if len(sys.argv) < 3:
        print("الاستخدام: python scan_manager.py <scan_id> <target_url> [scan_type]")
        sys.exit(1)
    
    scan_id = sys.argv[1]
    target_url = sys.argv[2]
    scan_type = sys.argv[3] if len(sys.argv) > 3 else 'quick'
    
    manager = ScanManager(scan_id, target_url, scan_type)
    
    if not manager.start_scan():
        print("فشل بدء عملية الفحص")
        sys.exit(1)
    
    print("جاري الفحص...")
    
    try:
        while True:
            status = manager.get_scan_status()
            print(f"الحالة: {status['status']}, التقدم: {status['progress']}%")
            
            if status['status'] in ['completed', 'failed', 'stopped']:
                break
            
            time.sleep(2)
        
        if status['status'] == 'completed':
            print("تم اكتمال عملية الفحص")
            
            results = manager.get_scan_results()
            print(f"تم العثور على {len(results['vulnerabilities'])} ثغرة")
        else:
            print(f"انتهت عملية الفحص بحالة: {status['status']}")
    except KeyboardInterrupt:
        print("تم إيقاف عملية الفحص بواسطة المستخدم")
        manager.stop_scan()

if __name__ == "__main__":
    main()
