#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
وحدة فحص الثغرات الأمنية باستخدام OWASP ZAP
"""

import sys
import os
import time
import json
import logging
from zapv2 import ZAPv2
from urllib.parse import urlparse

# إعداد التسجيل
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('zap_scanner')

class ZapScanner:
    """فاحص الثغرات الأمنية باستخدام OWASP ZAP"""
    
    def __init__(self, target_url, scan_type='quick', api_key=None):
        """
        تهيئة فاحص ZAP
        
        المعلمات:
            target_url (str): عنوان URL المستهدف للفحص
            scan_type (str): نوع الفحص ('quick', 'comprehensive', 'custom')
            api_key (str): مفتاح API لـ ZAP (اختياري)
        """
        self.target_url = target_url
        self.scan_type = scan_type
        self.api_key = api_key
        
        # تكوين ZAP API
        self.zap = None
        self.scan_id = None
        self.results = {
            'vulnerabilities': []
        }
        
        # تكوين مستوى الفحص
        self.scan_depth = 1 if scan_type == 'quick' else 3 if scan_type == 'comprehensive' else 2
        
    def connect_to_zap(self, zap_proxy='localhost', zap_port=8080):
        """
        الاتصال بخادم ZAP
        
        المعلمات:
            zap_proxy (str): عنوان خادم ZAP
            zap_port (int): منفذ خادم ZAP
            
        العوائد:
            bool: نجاح الاتصال
        """
        try:
            zap_url = f'http://{zap_proxy}:{zap_port}'
            logger.info(f'الاتصال بخادم ZAP على {zap_url}')
            
            # في بيئة الإنتاج، سيتم استخدام خادم ZAP حقيقي
            # هنا نقوم بمحاكاة الاتصال للتوضيح
            
            # self.zap = ZAPv2(apikey=self.api_key, proxies={'http': zap_url, 'https': zap_url})
            
            # محاكاة الاتصال
            self.zap = True
            
            logger.info('تم الاتصال بخادم ZAP بنجاح')
            return True
        except Exception as e:
            logger.error(f'فشل الاتصال بخادم ZAP: {str(e)}')
            return False
    
    def start_scan(self):
        """
        بدء فحص الثغرات الأمنية
        
        العوائد:
            bool: نجاح بدء الفحص
        """
        try:
            if not self.zap:
                logger.error('لم يتم الاتصال بخادم ZAP')
                return False
            
            logger.info(f'بدء فحص الموقع: {self.target_url}')
            
            # في بيئة الإنتاج، سيتم استخدام ZAP API لبدء الفحص
            # هنا نقوم بمحاكاة عملية الفحص للتوضيح
            
            # تحليل عنوان URL
            parsed_url = urlparse(self.target_url)
            
            # محاكاة بدء الفحص
            logger.info(f'تهيئة الفحص بعمق {self.scan_depth}')
            time.sleep(2)  # محاكاة وقت التهيئة
            
            # محاكاة معرف الفحص
            self.scan_id = 'zap_scan_' + str(int(time.time()))
            
            logger.info(f'تم بدء الفحص بنجاح. معرف الفحص: {self.scan_id}')
            return True
        except Exception as e:
            logger.error(f'فشل بدء الفحص: {str(e)}')
            return False
    
    def get_scan_status(self):
        """
        الحصول على حالة الفحص
        
        العوائد:
            dict: حالة الفحص
        """
        if not self.scan_id:
            return {'status': 'not_started', 'progress': 0}
        
        # في بيئة الإنتاج، سيتم استخدام ZAP API للحصول على حالة الفحص
        # هنا نقوم بمحاكاة حالة الفحص للتوضيح
        
        # محاكاة تقدم الفحص
        progress = min(100, int(time.time() % 100))
        
        status = 'in_progress'
        if progress >= 100:
            status = 'completed'
        
        return {
            'status': status,
            'progress': progress,
            'scan_id': self.scan_id
        }
    
    def get_scan_results(self):
        """
        الحصول على نتائج الفحص
        
        العوائد:
            dict: نتائج الفحص
        """
        if not self.scan_id:
            return {'vulnerabilities': []}
        
        # في بيئة الإنتاج، سيتم استخدام ZAP API للحصول على نتائج الفحص
        # هنا نقوم بمحاكاة نتائج الفحص للتوضيح
        
        # محاكاة نتائج الفحص
        self.results = {
            'vulnerabilities': [
                {
                    'type': 'sql_injection',
                    'name': 'SQL Injection in Login Form',
                    'description': 'تم اكتشاف ثغرة حقن SQL في نموذج تسجيل الدخول',
                    'severity': 'critical',
                    'location': f'{self.target_url}/login',
                    'evidence': {
                        'request': 'POST /login HTTP/1.1\nHost: example.com\n...',
                        'response': 'HTTP/1.1 200 OK\n...',
                        'payload': "' OR 1=1 --"
                    }
                },
                {
                    'type': 'xss',
                    'name': 'Cross-Site Scripting (XSS)',
                    'description': 'تم اكتشاف ثغرة XSS في صفحة البحث',
                    'severity': 'high',
                    'location': f'{self.target_url}/search',
                    'evidence': {
                        'request': 'GET /search?q=<script>alert(1)</script> HTTP/1.1\nHost: example.com\n...',
                        'response': 'HTTP/1.1 200 OK\n...',
                        'payload': '<script>alert(1)</script>'
                    }
                },
                {
                    'type': 'security_headers',
                    'name': 'Missing Security Headers',
                    'description': 'تم اكتشاف نقص في رؤوس الأمان مثل Content-Security-Policy و X-XSS-Protection',
                    'severity': 'low',
                    'location': self.target_url,
                    'evidence': {
                        'request': 'GET / HTTP/1.1\nHost: example.com\n...',
                        'response': 'HTTP/1.1 200 OK\n...',
                        'payload': None
                    }
                }
            ]
        }
        
        # إضافة ثغرات إضافية للفحص الشامل
        if self.scan_type == 'comprehensive':
            self.results['vulnerabilities'].extend([
                {
                    'type': 'csrf',
                    'name': 'Cross-Site Request Forgery (CSRF)',
                    'description': 'تم اكتشاف ثغرة CSRF في نموذج تحديث الملف الشخصي',
                    'severity': 'medium',
                    'location': f'{self.target_url}/profile',
                    'evidence': {
                        'request': 'POST /profile HTTP/1.1\nHost: example.com\n...',
                        'response': 'HTTP/1.1 200 OK\n...',
                        'payload': None
                    }
                },
                {
                    'type': 'insecure_cookies',
                    'name': 'Insecure Cookies',
                    'description': 'تم اكتشاف ملفات تعريف ارتباط غير آمنة بدون علامة Secure أو HttpOnly',
                    'severity': 'medium',
                    'location': self.target_url,
                    'evidence': {
                        'request': 'GET / HTTP/1.1\nHost: example.com\n...',
                        'response': 'HTTP/1.1 200 OK\nSet-Cookie: session=123; Path=/\n...',
                        'payload': None
                    }
                }
            ])
        
        return self.results
    
    def save_results_to_file(self, output_file):
        """
        حفظ نتائج الفحص إلى ملف
        
        المعلمات:
            output_file (str): مسار ملف الإخراج
            
        العوائد:
            bool: نجاح حفظ النتائج
        """
        try:
            results = self.get_scan_results()
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
            
            logger.info(f'تم حفظ نتائج الفحص إلى {output_file}')
            return True
        except Exception as e:
            logger.error(f'فشل حفظ نتائج الفحص: {str(e)}')
            return False
    
    def stop_scan(self):
        """
        إيقاف الفحص
        
        العوائد:
            bool: نجاح إيقاف الفحص
        """
        if not self.scan_id:
            logger.warning('لم يتم بدء الفحص بعد')
            return False
        
        try:
            logger.info(f'إيقاف الفحص: {self.scan_id}')
            
            # في بيئة الإنتاج، سيتم استخدام ZAP API لإيقاف الفحص
            # هنا نقوم بمحاكاة إيقاف الفحص للتوضيح
            
            # محاكاة إيقاف الفحص
            time.sleep(1)
            
            logger.info('تم إيقاف الفحص بنجاح')
            return True
        except Exception as e:
            logger.error(f'فشل إيقاف الفحص: {str(e)}')
            return False

def main():
    """الدالة الرئيسية"""
    if len(sys.argv) < 2:
        print("الاستخدام: python zap_scanner.py <target_url> [scan_type] [output_file]")
        sys.exit(1)
    
    target_url = sys.argv[1]
    scan_type = sys.argv[2] if len(sys.argv) > 2 else 'quick'
    output_file = sys.argv[3] if len(sys.argv) > 3 else 'zap_results.json'
    
    scanner = ZapScanner(target_url, scan_type)
    
    if not scanner.connect_to_zap():
        print("فشل الاتصال بخادم ZAP")
        sys.exit(1)
    
    if not scanner.start_scan():
        print("فشل بدء الفحص")
        sys.exit(1)
    
    print("جاري الفحص...")
    
    while True:
        status = scanner.get_scan_status()
        print(f"التقدم: {status['progress']}%")
        
        if status['status'] == 'completed':
            break
        
        time.sleep(1)
    
    print("تم اكتمال الفحص")
    
    results = scanner.get_scan_results()
    print(f"تم العثور على {len(results['vulnerabilities'])} ثغرة")
    
    scanner.save_results_to_file(output_file)
    print(f"تم حفظ النتائج إلى {output_file}")

if __name__ == "__main__":
    main()
