const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

class ReportGenerator {
  /**
   * إنشاء مولد التقارير
   * @param {Object} options خيارات التكوين
   */
  constructor(options = {}) {
    this.options = {
      outputDir: options.outputDir || path.join(__dirname, '..', 'reports'),
      templateDir: options.templateDir || path.join(__dirname, '..', 'templates'),
      ...options
    };

    // إنشاء دليل التقارير إذا لم يكن موجودًا
    if (!fs.existsSync(this.options.outputDir)) {
      fs.mkdirSync(this.options.outputDir, { recursive: true });
    }
  }

  /**
   * إنشاء تقرير PDF
   * @param {Object} scanData بيانات الفحص
   * @param {Array} vulnerabilities قائمة الثغرات المكتشفة
   * @param {String} outputFile اسم ملف الإخراج (اختياري)
   * @returns {Promise<String>} مسار ملف التقرير
   */
  async generatePdfReport(scanData, vulnerabilities, outputFile = null) {
    return new Promise((resolve, reject) => {
      try {
        // تحديد اسم ملف الإخراج
        const filename = outputFile || `vulnerability_report_${scanData.id || Date.now()}.pdf`;
        const outputPath = path.join(this.options.outputDir, filename);

        // إنشاء مستند PDF
        const doc = new PDFDocument({ size: 'A4', margin: 50, rtl: true });
        const stream = fs.createWriteStream(outputPath);

        // معالجة الأحداث
        stream.on('finish', () => {
          resolve(outputPath);
        });

        stream.on('error', (err) => {
          reject(err);
        });

        // توجيه المخرجات إلى الملف
        doc.pipe(stream);

        // إضافة العنوان
        doc.font('Helvetica-Bold').fontSize(24).text('تقرير فحص الثغرات الأمنية', { align: 'center' });
        doc.moveDown();

        // إضافة معلومات الفحص
        doc.font('Helvetica-Bold').fontSize(16).text('معلومات الفحص', { align: 'right' });
        doc.moveDown(0.5);

        doc.font('Helvetica').fontSize(12);
        doc.text(`الموقع المستهدف: ${scanData.targetUrl}`, { align: 'right' });
        doc.text(`نوع الفحص: ${this._translateScanType(scanData.scanType)}`, { align: 'right' });
        doc.text(`تاريخ البدء: ${this._formatDate(scanData.startTime)}`, { align: 'right' });
        doc.text(`تاريخ الانتهاء: ${this._formatDate(scanData.endTime)}`, { align: 'right' });
        doc.text(`المدة: ${this._calculateDuration(scanData.startTime, scanData.endTime)}`, { align: 'right' });
        doc.moveDown();

        // إضافة ملخص النتائج
        doc.font('Helvetica-Bold').fontSize(16).text('ملخص النتائج', { align: 'right' });
        doc.moveDown(0.5);

        doc.font('Helvetica').fontSize(12);
        const summary = this._generateSummary(vulnerabilities);
        doc.text(`إجمالي الثغرات: ${summary.total}`, { align: 'right' });
        doc.text(`ثغرات حرجة: ${summary.critical}`, { align: 'right' });
        doc.text(`ثغرات عالية: ${summary.high}`, { align: 'right' });
        doc.text(`ثغرات متوسطة: ${summary.medium}`, { align: 'right' });
        doc.text(`ثغرات منخفضة: ${summary.low}`, { align: 'right' });
        doc.text(`معلومات: ${summary.info}`, { align: 'right' });
        doc.moveDown();

        // إضافة قائمة الثغرات
        doc.font('Helvetica-Bold').fontSize(16).text('الثغرات المكتشفة', { align: 'right' });
        doc.moveDown(0.5);

        // ترتيب الثغرات حسب مستوى الخطورة
        const sortedVulnerabilities = this._sortVulnerabilitiesBySeverity(vulnerabilities);

        // إضافة تفاصيل كل ثغرة
        sortedVulnerabilities.forEach((vuln, index) => {
          doc.font('Helvetica-Bold').fontSize(14).text(`${index + 1}. ${vuln.name}`, { align: 'right' });
          doc.font('Helvetica').fontSize(12);
          doc.text(`مستوى الخطورة: ${this._translateSeverity(vuln.severity)}`, { align: 'right' });
          doc.text(`النوع: ${vuln.category || vuln.type || 'غير محدد'}`, { align: 'right' });
          doc.text(`الموقع: ${vuln.location || 'غير محدد'}`, { align: 'right' });
          doc.text(`الوصف: ${vuln.description}`, { align: 'right' });

          if (vuln.remediation) {
            doc.text(`الإصلاح: ${vuln.remediation}`, { align: 'right' });
          }

          if (vuln.references && vuln.references.length > 0) {
            doc.text('المراجع:', { align: 'right' });
            vuln.references.forEach(ref => {
              doc.text(`- ${ref.title}: ${ref.url}`, { align: 'right' });
            });
          }

          doc.moveDown();
        });

        // إضافة التوصيات
        doc.font('Helvetica-Bold').fontSize(16).text('التوصيات العامة', { align: 'right' });
        doc.moveDown(0.5);

        doc.font('Helvetica').fontSize(12);
        doc.text('1. قم بتحديث جميع البرامج والمكونات المستخدمة في الموقع بانتظام.', { align: 'right' });
        doc.text('2. استخدم سياسة أمان المحتوى (CSP) لتقييد تنفيذ النصوص البرمجية.', { align: 'right' });
        doc.text('3. قم بتنفيذ التحقق من المدخلات وترميز المخرجات بشكل صحيح.', { align: 'right' });
        doc.text('4. استخدم الاستعلامات المعدة مسبقًا لمنع هجمات حقن SQL.', { align: 'right' });
        doc.text('5. قم بإضافة رؤوس الأمان المناسبة لتحسين أمان الموقع.', { align: 'right' });
        doc.moveDown();

        // إضافة تذييل الصفحة
        doc.fontSize(10).text(`تم إنشاء هذا التقرير بواسطة منصة كشف الثغرات الأمنية بتاريخ ${this._formatDate(new Date())}`, { align: 'center' });

        // إنهاء المستند
        doc.end();
      } catch (err) {
        reject(err);
      }
    });
  }

  /**
   * إنشاء تقرير CSV
   * @param {Object} scanData بيانات الفحص
   * @param {Array} vulnerabilities قائمة الثغرات المكتشفة
   * @param {String} outputFile اسم ملف الإخراج (اختياري)
   * @returns {Promise<String>} مسار ملف التقرير
   */
  async generateCsvReport(scanData, vulnerabilities, outputFile = null) {
    try {
      // تحديد اسم ملف الإخراج
      const filename = outputFile || `vulnerability_report_${scanData.id || Date.now()}.csv`;
      const outputPath = path.join(this.options.outputDir, filename);

      // تكوين كاتب CSV
      const csvWriter = createCsvWriter({
        path: outputPath,
        header: [
          { id: 'name', title: 'Name' },
          { id: 'severity', title: 'Severity' },
          { id: 'category', title: 'Category' },
          { id: 'location', title: 'Location' },
          { id: 'description', title: 'Description' },
          { id: 'remediation', title: 'Remediation' },
          { id: 'cweId', title: 'CWE ID' }
        ]
      });

      // تحضير البيانات
      const records = vulnerabilities.map(vuln => ({
        name: vuln.name,
        severity: vuln.severity,
        category: vuln.category || vuln.type || '',
        location: vuln.location || '',
        description: vuln.description,
        remediation: vuln.remediation || '',
        cweId: vuln.cweId || ''
      }));

      // كتابة البيانات
      await csvWriter.writeRecords(records);

      return outputPath;
    } catch (err) {
      throw err;
    }
  }

  /**
   * إنشاء تقرير HTML
   * @param {Object} scanData بيانات الفحص
   * @param {Array} vulnerabilities قائمة الثغرات المكتشفة
   * @param {String} outputFile اسم ملف الإخراج (اختياري)
   * @returns {Promise<String>} مسار ملف التقرير
   */
  async generateHtmlReport(scanData, vulnerabilities, outputFile = null) {
    try {
      // تحديد اسم ملف الإخراج
      const filename = outputFile || `vulnerability_report_${scanData.id || Date.now()}.html`;
      const outputPath = path.join(this.options.outputDir, filename);

      // ترتيب الثغرات حسب مستوى الخطورة
      const sortedVulnerabilities = this._sortVulnerabilitiesBySeverity(vulnerabilities);

      // إنشاء ملخص
      const summary = this._generateSummary(vulnerabilities);

      // إنشاء محتوى HTML
      let htmlContent = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تقرير فحص الثغرات الأمنية</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 20px;
      color: #333;
      direction: rtl;
    }
    h1 {
      color: #2c3e50;
      text-align: center;
      margin-bottom: 30px;
    }
    h2 {
      color: #3498db;
      border-bottom: 1px solid #eee;
      padding-bottom: 10px;
      margin-top: 30px;
    }
    h3 {
      color: #2c3e50;
      margin-top: 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background-color: #fff;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .info-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    .info-table th, .info-table td {
      padding: 12px;
      text-align: right;
      border-bottom: 1px solid #ddd;
    }
    .info-table th {
      background-color: #f8f9fa;
      font-weight: bold;
      width: 30%;
    }
    .summary-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    .summary-table th, .summary-table td {
      padding: 12px;
      text-align: center;
      border: 1px solid #ddd;
    }
    .summary-table th {
      background-color: #f8f9fa;
      font-weight: bold;
    }
    .vulnerability {
      margin-bottom: 30px;
      padding: 15px;
      border-radius: 5px;
      background-color: #f8f9fa;
      border-right: 5px solid #3498db;
    }
    .critical {
      border-right-color: #e74c3c;
    }
    .high {
      border-right-color: #e67e22;
    }
    .medium {
      border-right-color: #f1c40f;
    }
    .low {
      border-right-color: #3498db;
    }
    .info {
      border-right-color: #95a5a6;
    }
    .severity {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 3px;
      color: white;
      font-weight: bold;
      margin-right: 10px;
    }
    .severity.critical {
      background-color: #e74c3c;
    }
    .severity.high {
      background-color: #e67e22;
    }
    .severity.medium {
      background-color: #f1c40f;
    }
    .severity.low {
      background-color: #3498db;
    }
    .severity.info {
      background-color: #95a5a6;
    }
    .recommendations {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 5px;
      margin-top: 30px;
    }
    .recommendations ul {
      margin-top: 10px;
    }
    .footer {
      text-align: center;
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #eee;
      color: #7f8c8d;
      font-size: 0.9em;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>تقرير فحص الثغرات الأمنية</h1>
    
    <h2>معلومات الفحص</h2>
    <table class="info-table">
      <tr>
        <th>الموقع المستهدف</th>
        <td>${scanData.targetUrl}</td>
      </tr>
      <tr>
        <th>نوع الفحص</th>
        <td>${this._translateScanType(scanData.scanType)}</td>
      </tr>
      <tr>
        <th>تاريخ البدء</th>
        <td>${this._formatDate(scanData.startTime)}</td>
      </tr>
      <tr>
        <th>تاريخ الانتهاء</th>
        <td>${this._formatDate(scanData.endTime)}</td>
      </tr>
      <tr>
        <th>المدة</th>
        <td>${this._calculateDuration(scanData.startTime, scanData.endTime)}</td>
      </tr>
    </table>
    
    <h2>ملخص النتائج</h2>
    <table class="summary-table">
      <tr>
        <th>إجمالي الثغرات</th>
        <th>ثغرات حرجة</th>
        <th>ثغرات عالية</th>
        <th>ثغرات متوسطة</th>
        <th>ثغرات منخفضة</th>
        <th>معلومات</th>
      </tr>
      <tr>
        <td>${summary.total}</td>
        <td>${summary.critical}</td>
        <td>${summary.high}</td>
        <td>${summary.medium}</td>
        <td>${summary.low}</td>
        <td>${summary.info}</td>
      </tr>
    </table>
    
    <h2>الثغرات المكتشفة</h2>`;

      // إضافة تفاصيل كل ثغرة
      sortedVulnerabilities.forEach((vuln, index) => {
        htmlContent += `
    <div class="vulnerability ${vuln.severity}">
      <h3>${index + 1}. ${vuln.name}</h3>
      <p><span class="severity ${vuln.severity}">${this._translateSeverity(vuln.severity)}</span></p>
      <p><strong>النوع:</strong> ${vuln.category || vuln.type || 'غير محدد'}</p>
      <p><strong>الموقع:</strong> ${vuln.location || 'غير محدد'}</p>
      <p><strong>الوصف:</strong> ${vuln.description}</p>`;

        if (vuln.remediation) {
          htmlContent += `
      <p><strong>الإصلاح:</strong> ${vuln.remediation}</p>`;
        }

        if (vuln.references && vuln.references.length > 0) {
          htmlContent += `
      <p><strong>المراجع:</strong></p>
      <ul>`;
          vuln.references.forEach(ref => {
            htmlContent += `
        <li><a href="${ref.url}" target="_blank">${ref.title}</a></li>`;
          });
          htmlContent += `
      </ul>`;
        }

        htmlContent += `
    </div>`;
      });

      // إضافة التوصيات وتذييل الصفحة
      htmlContent += `
    <div class="recommendations">
      <h2>التوصيات العامة</h2>
      <ul>
        <li>قم بتحديث جميع البرامج والمكونات المستخدمة في الموقع بانتظام.</li>
        <li>استخدم سياسة أمان المحتوى (CSP) لتقييد تنفيذ النصوص البرمجية.</li>
        <li>قم بتنفيذ التحقق من المدخلات وترميز المخرجات بشكل صحيح.</li>
        <li>استخدم الاستعلامات المعدة مسبقًا لمنع هجمات حقن SQL.</li>
        <li>قم بإضافة رؤوس الأمان المناسبة لتحسين أمان الموقع.</li>
      </ul>
    </div>
    
    <div class="footer">
      <p>تم إنشاء هذا التقرير بواسطة منصة كشف الثغرات الأمنية بتاريخ ${this._formatDate(new Date())}</p>
    </div>
  </div>
</body>
</html>`;

      // كتابة محتوى HTML إلى الملف
      fs.writeFileSync(outputPath, htmlContent, 'utf8');

      return outputPath;
    } catch (err) {
      throw err;
    }
  }

  /**
   * إنشاء تقرير JSON
   * @param {Object} scanData بيانات الفحص
   * @param {Array} vulnerabilities قائمة الثغرات المكتشفة
   * @param {String} outputFile اسم ملف الإخراج (اختياري)
   * @returns {Promise<String>} مسار ملف التقرير
   */
  async generateJsonReport(scanData, vulnerabilities, outputFile = null) {
    try {
      // تحديد اسم ملف الإخراج
      const filename = outputFile || `vulnerability_report_${scanData.id || Date.now()}.json`;
      const outputPath = path.join(this.options.outputDir, filename);

      // إنشاء ملخص
      const summary = this._generateSummary(vulnerabilities);

      // إنشاء كائن التقرير
      const report = {
        scanInfo: {
          id: scanData.id,
          targetUrl: scanData.targetUrl,
          scanType: scanData.scanType,
          startTime: scanData.startTime,
          endTime: scanData.endTime,
          duration: this._calculateDurationInSeconds(scanData.startTime, scanData.endTime)
        },
        summary: summary,
        vulnerabilities: vulnerabilities
      };

      // كتابة البيانات إلى ملف JSON
      fs.writeFileSync(outputPath, JSON.stringify(report, null, 2), 'utf8');

      return outputPath;
    } catch (err) {
      throw err;
    }
  }

  /**
   * ترجمة نوع الفحص
   * @param {String} scanType نوع الفحص
   * @returns {String} النوع المترجم
   * @private
   */
  _translateScanType(scanType) {
    switch (scanType) {
      case 'quick': return 'فحص سريع';
      case 'comprehensive': return 'فحص شامل';
      case 'custom': return 'فحص مخصص';
      default: return scanType;
    }
  }

  /**
   * ترجمة مستوى الخطورة
   * @param {String} severity مستوى الخطورة
   * @returns {String} المستوى المترجم
   * @private
   */
  _translateSeverity(severity) {
    switch (severity) {
      case 'critical': return 'حرج';
      case 'high': return 'عالي';
      case 'medium': return 'متوسط';
      case 'low': return 'منخفض';
      case 'info': return 'معلومات';
      default: return severity;
    }
  }

  /**
   * تنسيق التاريخ
   * @param {Date|String} date التاريخ
   * @returns {String} التاريخ المنسق
   * @private
   */
  _formatDate(date) {
    if (!date) return 'غير محدد';
    
    const d = new Date(date);
    if (isNaN(d.getTime())) return 'غير محدد';
    
    return d.toLocaleString('ar-SA');
  }

  /**
   * حساب المدة بين تاريخين
   * @param {Date|String} startTime وقت البدء
   * @param {Date|String} endTime وقت الانتهاء
   * @returns {String} المدة المنسقة
   * @private
   */
  _calculateDuration(startTime, endTime) {
    if (!startTime || !endTime) return 'غير محدد';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return 'غير محدد';
    
    const durationMs = end - start;
    const minutes = Math.floor(durationMs / 60000);
    const seconds = Math.floor((durationMs % 60000) / 1000);
    
    return `${minutes} دقيقة و ${seconds} ثانية`;
  }

  /**
   * حساب المدة بين تاريخين بالثواني
   * @param {Date|String} startTime وقت البدء
   * @param {Date|String} endTime وقت الانتهاء
   * @returns {Number} المدة بالثواني
   * @private
   */
  _calculateDurationInSeconds(startTime, endTime) {
    if (!startTime || !endTime) return 0;
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return 0;
    
    return Math.floor((end - start) / 1000);
  }

  /**
   * إنشاء ملخص للثغرات
   * @param {Array} vulnerabilities قائمة الثغرات
   * @returns {Object} ملخص الثغرات
   * @private
   */
  _generateSummary(vulnerabilities) {
    const summary = {
      total: vulnerabilities.length,
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      info: 0
    };

    vulnerabilities.forEach(vuln => {
      switch (vuln.severity) {
        case 'critical': summary.critical++; break;
        case 'high': summary.high++; break;
        case 'medium': summary.medium++; break;
        case 'low': summary.low++; break;
        case 'info': summary.info++; break;
      }
    });

    return summary;
  }

  /**
   * ترتيب الثغرات حسب مستوى الخطورة
   * @param {Array} vulnerabilities قائمة الثغرات
   * @returns {Array} قائمة الثغرات المرتبة
   * @private
   */
  _sortVulnerabilitiesBySeverity(vulnerabilities) {
    const severityOrder = {
      'critical': 0,
      'high': 1,
      'medium': 2,
      'low': 3,
      'info': 4
    };

    return [...vulnerabilities].sort((a, b) => {
      const severityA = severityOrder[a.severity] !== undefined ? severityOrder[a.severity] : 999;
      const severityB = severityOrder[b.severity] !== undefined ? severityOrder[b.severity] : 999;
      
      return severityA - severityB;
    });
  }
}

module.exports = ReportGenerator;
