const mongoose = require('mongoose');
const Vulnerability = require('../models/Vulnerability');
const fs = require('fs');
const path = require('path');

// قائمة الثغرات الأمنية المتعلقة بتطبيقات الويب
const webVulnerabilities = [
  {
    name: 'Local File Inclusion (LFI)',
    description: 'تحدث ثغرات تضمين الملفات المحلية عندما يسمح التطبيق للمستخدم بتحديد ملف محلي للتضمين دون التحقق بشكل صحيح من المدخلات، مما قد يؤدي إلى الكشف عن محتويات ملفات حساسة.',
    severity: 'high',
    category: 'file_inclusion',
    cweId: 'CWE-98',
    remediation: 'تجنب استخدام مدخلات المستخدم في أسماء الملفات، وتنفيذ قوائم بيضاء للملفات المسموح بها، وتقييد الوصول إلى الملفات الحساسة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'file inclusion',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Local File Inclusion',
        url: 'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/11.1-Testing_for_Local_File_Inclusion'
      },
      {
        title: 'MITRE CWE-98: Improper Control of Filename for Include/Require Statement in PHP Program',
        url: 'https://cwe.mitre.org/data/definitions/98.html'
      }
    ]
  },
  {
    name: 'Remote File Inclusion (RFI)',
    description: 'تحدث ثغرات تضمين الملفات البعيدة عندما يسمح التطبيق للمستخدم بتحديد ملف بعيد للتضمين دون التحقق بشكل صحيح من المدخلات، مما قد يؤدي إلى تنفيذ تعليمات برمجية ضارة.',
    severity: 'critical',
    category: 'file_inclusion',
    cweId: 'CWE-98',
    remediation: 'تعطيل تضمين الملفات البعيدة، وتنفيذ قوائم بيضاء للملفات المسموح بها، وتصفية مدخلات المستخدم.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'remote file inclusion',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Remote File Inclusion',
        url: 'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/11.2-Testing_for_Remote_File_Inclusion'
      },
      {
        title: 'MITRE CWE-98: Improper Control of Filename for Include/Require Statement in PHP Program',
        url: 'https://cwe.mitre.org/data/definitions/98.html'
      }
    ]
  },
  {
    name: 'Insecure Direct Object References (IDOR)',
    description: 'تحدث ثغرات IDOR عندما يكشف التطبيق عن مرجع لكائن تنفيذ داخلي، مثل ملف أو دليل أو مفتاح قاعدة بيانات، دون التحقق من الوصول، مما يسمح للمهاجمين بالتلاعب بهذه المراجع للوصول إلى بيانات غير مصرح بها.',
    severity: 'high',
    category: 'access_control',
    cweId: 'CWE-639',
    remediation: 'استخدام مراجع غير مباشرة، وتنفيذ التحقق من الوصول لكل طلب، واستخدام نموذج الوصول القائم على الأدوار.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'idor',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Insecure Direct Object Reference Prevention',
        url: 'https://cheatsheetseries.owasp.org/cheatsheets/Insecure_Direct_Object_Reference_Prevention_Cheat_Sheet.html'
      },
      {
        title: 'MITRE CWE-639: Authorization Bypass Through User-Controlled Key',
        url: 'https://cwe.mitre.org/data/definitions/639.html'
      }
    ]
  },
  {
    name: 'Missing Function Level Access Control',
    description: 'تحدث هذه الثغرة عندما لا يتحقق التطبيق من صلاحيات المستخدم عند الوصول إلى وظائف حساسة، مما يسمح للمهاجمين بالوصول إلى وظائف غير مصرح بها.',
    severity: 'high',
    category: 'access_control',
    cweId: 'CWE-285',
    remediation: 'تنفيذ التحقق من الوصول على مستوى الوظيفة، وتطبيق مبدأ الرفض الافتراضي، واستخدام نموذج الوصول القائم على الأدوار.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'access control',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Access Control',
        url: 'https://owasp.org/www-community/Access_Control'
      },
      {
        title: 'MITRE CWE-285: Improper Authorization',
        url: 'https://cwe.mitre.org/data/definitions/285.html'
      }
    ]
  },
  {
    name: 'Security Misconfiguration - Default Credentials',
    description: 'تحدث هذه الثغرة عندما يتم نشر التطبيق مع بيانات اعتماد افتراضية أو ضعيفة، مما يسمح للمهاجمين بالوصول غير المصرح به.',
    severity: 'high',
    category: 'configuration',
    cweId: 'CWE-1188',
    remediation: 'تغيير جميع كلمات المرور الافتراضية، وتعطيل الحسابات غير المستخدمة، وتنفيذ عملية آمنة لإدارة كلمات المرور.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'default credentials',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Default Credentials',
        url: 'https://owasp.org/www-community/vulnerabilities/Use_of_Default_Credentials'
      },
      {
        title: 'MITRE CWE-1188: Insecure Default Initialization of Resource',
        url: 'https://cwe.mitre.org/data/definitions/1188.html'
      }
    ]
  },
  {
    name: 'Security Headers Missing',
    description: 'تحدث هذه الثغرة عندما لا يتم تكوين رؤوس الأمان المهمة مثل Content-Security-Policy و X-XSS-Protection و X-Content-Type-Options، مما يزيد من خطر الهجمات مثل XSS وClickjacking.',
    severity: 'medium',
    category: 'configuration',
    cweId: 'CWE-693',
    remediation: 'تكوين رؤوس الأمان المناسبة، وتنفيذ سياسة أمان المحتوى، واستخدام أدوات مثل Helmet.js لإدارة رؤوس الأمان.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'security headers',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Secure Headers Project',
        url: 'https://owasp.org/www-project-secure-headers/'
      },
      {
        title: 'MITRE CWE-693: Protection Mechanism Failure',
        url: 'https://cwe.mitre.org/data/definitions/693.html'
      }
    ]
  },
  {
    name: 'Sensitive Data Exposure',
    description: 'تحدث هذه الثغرة عندما لا يحمي التطبيق البيانات الحساسة مثل بيانات الاعتماد أو المعلومات الشخصية أو بيانات بطاقات الائتمان بشكل كافٍ.',
    severity: 'high',
    category: 'data_protection',
    cweId: 'CWE-200',
    remediation: 'تشفير البيانات الحساسة أثناء النقل والتخزين، وتنفيذ HTTPS، وتقليل كمية البيانات الحساسة المخزنة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'sensitive data',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Sensitive Data Exposure',
        url: 'https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure'
      },
      {
        title: 'MITRE CWE-200: Exposure of Sensitive Information to an Unauthorized Actor',
        url: 'https://cwe.mitre.org/data/definitions/200.html'
      }
    ]
  },
  {
    name: 'Clickjacking',
    description: 'تحدث ثغرة Clickjacking عندما يتم خداع المستخدم للنقر على عنصر مخفي في صفحة ويب، مما قد يؤدي إلى تنفيذ إجراءات غير مقصودة.',
    severity: 'medium',
    category: 'ui_redressing',
    cweId: 'CWE-1021',
    remediation: 'تنفيذ رأس X-Frame-Options أو Content-Security-Policy مع تعليمة frame-ancestors، ومنع تضمين الصفحات الحساسة في إطارات.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'clickjacking',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Clickjacking',
        url: 'https://owasp.org/www-community/attacks/Clickjacking'
      },
      {
        title: 'MITRE CWE-1021: Improper Restriction of Rendered UI Layers or Frames',
        url: 'https://cwe.mitre.org/data/definitions/1021.html'
      }
    ]
  },
  {
    name: 'Open Redirect',
    description: 'تحدث ثغرة Open Redirect عندما يسمح التطبيق بإعادة توجيه المستخدم إلى موقع ويب خارجي دون التحقق بشكل صحيح من المدخلات، مما قد يسهل هجمات التصيد.',
    severity: 'medium',
    category: 'url_redirection',
    cweId: 'CWE-601',
    remediation: 'تجنب استخدام إعادة التوجيه إلى مواقع خارجية، وتنفيذ قوائم بيضاء للوجهات المسموح بها، والتحقق من صحة وجهات إعادة التوجيه.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'open redirect',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Open Redirect',
        url: 'https://cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html'
      },
      {
        title: 'MITRE CWE-601: URL Redirection to Untrusted Site',
        url: 'https://cwe.mitre.org/data/definitions/601.html'
      }
    ]
  },
  {
    name: 'Path Traversal',
    description: 'تحدث ثغرة Path Traversal عندما يسمح التطبيق للمستخدم بالوصول إلى ملفات خارج الدليل المقصود باستخدام سلاسل مثل "../".',
    severity: 'high',
    category: 'file_system',
    cweId: 'CWE-22',
    remediation: 'تصفية وتطهير مدخلات المستخدم، وتقييد الوصول إلى نظام الملفات، واستخدام واجهات برمجة تطبيقات آمنة للوصول إلى الملفات.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'path traversal',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Path Traversal',
        url: 'https://owasp.org/www-community/attacks/Path_Traversal'
      },
      {
        title: 'MITRE CWE-22: Improper Limitation of a Pathname to a Restricted Directory',
        url: 'https://cwe.mitre.org/data/definitions/22.html'
      }
    ]
  }
];

// قائمة الثغرات الأمنية المتعلقة بالبنية التحتية
const infrastructureVulnerabilities = [
  {
    name: 'SSL/TLS Weak Configuration',
    description: 'تحدث هذه الثغرة عندما يتم تكوين SSL/TLS بشكل غير آمن، مثل استخدام بروتوكولات أو خوارزميات تشفير ضعيفة، مما قد يسمح بهجمات Man-in-the-Middle.',
    severity: 'high',
    category: 'cryptography',
    cweId: 'CWE-327',
    remediation: 'تعطيل البروتوكولات القديمة مثل SSLv2/v3 و TLS 1.0/1.1، واستخدام خوارزميات تشفير قوية، وتكوين ترتيب التشفير بشكل صحيح.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'ssl',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Transport Layer Protection',
        url: 'https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html'
      },
      {
        title: 'MITRE CWE-327: Use of a Broken or Risky Cryptographic Algorithm',
        url: 'https://cwe.mitre.org/data/definitions/327.html'
      }
    ]
  },
  {
    name: 'Insecure Cookie Configuration',
    description: 'تحدث هذه الثغرة عندما لا يتم تكوين ملفات تعريف الارتباط بشكل آمن، مثل عدم استخدام علامات Secure أو HttpOnly أو SameSite، مما قد يسمح بسرقة الجلسات.',
    severity: 'medium',
    category: 'session_management',
    cweId: 'CWE-614',
    remediation: 'تكوين ملفات تعريف الارتباط مع علامات Secure و HttpOnly و SameSite، وتعيين تواريخ انتهاء صلاحية مناسبة، واستخدام أسماء غير قابلة للتنبؤ.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'cookie',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Session Management',
        url: 'https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'
      },
      {
        title: 'MITRE CWE-614: Sensitive Cookie in HTTPS Session Without Secure Attribute',
        url: 'https://cwe.mitre.org/data/definitions/614.html'
      }
    ]
  },
  {
    name: 'Information Disclosure - Server Information',
    description: 'تحدث هذه الثغرة عندما يكشف الخادم عن معلومات حساسة مثل إصدار البرنامج أو نوع الخادم، مما قد يساعد المهاجمين في استهداف ثغرات معروفة.',
    severity: 'low',
    category: 'information_disclosure',
    cweId: 'CWE-200',
    remediation: 'إزالة أو تعديل رؤوس الخادم، وتعطيل رسائل الخطأ المفصلة، وإخفاء إصدارات البرامج والتكنولوجيا المستخدمة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'information disclosure',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Information Leakage',
        url: 'https://owasp.org/www-community/Improper_Error_Handling'
      },
      {
        title: 'MITRE CWE-200: Exposure of Sensitive Information to an Unauthorized Actor',
        url: 'https://cwe.mitre.org/data/definitions/200.html'
      }
    ]
  },
  {
    name: 'Directory Listing Enabled',
    description: 'تحدث هذه الثغرة عندما يتم تمكين قوائم الدليل على الخادم، مما يسمح للمهاجمين بعرض محتويات الدليل واكتشاف ملفات حساسة.',
    severity: 'medium',
    category: 'information_disclosure',
    cweId: 'CWE-548',
    remediation: 'تعطيل قوائم الدليل على الخادم، وإضافة ملفات index.html فارغة في الدلائل، وتقييد الوصول إلى الدلائل الحساسة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'directory listing',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Directory Listing',
        url: 'https://owasp.org/www-community/attacks/Directory_indexing'
      },
      {
        title: 'MITRE CWE-548: Exposure of Information Through Directory Listing',
        url: 'https://cwe.mitre.org/data/definitions/548.html'
      }
    ]
  },
  {
    name: 'Insecure HTTP Methods Enabled',
    description: 'تحدث هذه الثغرة عندما يتم تمكين طرق HTTP غير آمنة مثل PUT و DELETE و TRACE، مما قد يسمح للمهاجمين بتعديل محتوى الخادم أو تنفيذ هجمات أخرى.',
    severity: 'medium',
    category: 'configuration',
    cweId: 'CWE-749',
    remediation: 'تعطيل طرق HTTP غير الضرورية، وتقييد الوصول إلى طرق HTTP الحساسة، وتنفيذ التحقق من الصلاحيات لجميع الطلبات.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'http method',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Testing for HTTP Methods',
        url: 'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/02-Configuration_and_Deployment_Management_Testing/06-Test_HTTP_Methods'
      },
      {
        title: 'MITRE CWE-749: Exposed Dangerous Method or Function',
        url: 'https://cwe.mitre.org/data/definitions/749.html'
      }
    ]
  }
];

// دمج جميع قوائم الثغرات
const allVulnerabilities = [...webVulnerabilities, ...infrastructureVulnerabilities];

// وظيفة لتعبئة قاعدة البيانات بالثغرات الإضافية
const seedAdditionalVulnerabilities = async () => {
  try {
    console.log('بدء تعبئة قاعدة البيانات بالثغرات الإضافية');
    
    // إضافة الثغرات الجديدة
    await Vulnerability.insertMany(allVulnerabilities);
    
    console.log(`تم إضافة ${allVulnerabilities.length} ثغرة إضافية إلى قاعدة البيانات`);
    
    return { success: true, count: allVulnerabilities.length };
  } catch (err) {
    console.error('حدث خطأ أثناء تعبئة قاعدة البيانات بالثغرات الإضافية:', err);
    return { success: false, error: err.message };
  }
};

// تصدير الوظيفة
module.exports = {
  seedAdditionalVulnerabilities
};

// تنفيذ التعبئة إذا تم تشغيل الملف مباشرة
if (require.main === module) {
  // التأكد من الاتصال بقاعدة البيانات
  mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/vulnerability_scanner', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(async () => {
    console.log('تم الاتصال بقاعدة البيانات بنجاح');
    
    // تعبئة قاعدة البيانات
    const result = await seedAdditionalVulnerabilities();
    
    if (result.success) {
      console.log(`تم تعبئة قاعدة البيانات بنجاح. تم إضافة ${result.count} ثغرة إضافية.`);
    } else {
      console.error(`فشل تعبئة قاعدة البيانات: ${result.error}`);
    }
    
    // إغلاق الاتصال بقاعدة البيانات
    mongoose.connection.close();
  })
  .catch((err) => {
    console.error('فشل الاتصال بقاعدة البيانات:', err);
  });
}
