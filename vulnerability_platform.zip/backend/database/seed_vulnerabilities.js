const mongoose = require('mongoose');
const Vulnerability = require('../models/Vulnerability');
const fs = require('fs');
const path = require('path');

// قائمة الثغرات الأمنية من OWASP Top 10 2021
const owaspTop10 = [
  {
    name: 'Broken Access Control',
    description: 'تحدث ثغرات التحكم في الوصول عندما لا يتم تطبيق القيود المناسبة على ما يمكن للمستخدمين المصرح لهم القيام به، مما يسمح للمهاجمين بالوصول إلى بيانات أو وظائف غير مصرح بها.',
    severity: 'critical',
    category: 'access_control',
    cweId: 'CWE-284',
    remediation: 'تنفيذ آليات قوية للتحكم في الوصول، وتطبيق مبدأ الامتيازات الأقل، وإنكار الوصول افتراضيًا، وتنفيذ ضوابط الوصول على مستوى الخادم، وتعطيل قوائم الدليل، وتسجيل أخطاء التحكم في الوصول.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'access control',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A01:2021 – Broken Access Control',
        url: 'https://owasp.org/Top10/A01_2021-Broken_Access_Control/'
      },
      {
        title: 'MITRE CWE-284: Improper Access Control',
        url: 'https://cwe.mitre.org/data/definitions/284.html'
      }
    ]
  },
  {
    name: 'Cryptographic Failures',
    description: 'تحدث إخفاقات التشفير عندما تفشل التطبيقات في حماية البيانات الحساسة بشكل صحيح، مثل كلمات المرور أو المعلومات الشخصية أو بيانات بطاقات الائتمان.',
    severity: 'high',
    category: 'cryptography',
    cweId: 'CWE-310',
    remediation: 'تشفير جميع البيانات الحساسة أثناء النقل باستخدام TLS، وتخزين البيانات الحساسة بشكل مشفر، واستخدام خوارزميات تشفير قوية وحديثة، وتطبيق سياسات أمان صارمة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'cryptographic',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A02:2021 – Cryptographic Failures',
        url: 'https://owasp.org/Top10/A02_2021-Cryptographic_Failures/'
      },
      {
        title: 'MITRE CWE-310: Cryptographic Issues',
        url: 'https://cwe.mitre.org/data/definitions/310.html'
      }
    ]
  },
  {
    name: 'Injection',
    description: 'تحدث ثغرات الحقن عندما يتم إرسال بيانات غير موثوقة إلى المترجم كجزء من الأمر أو الاستعلام، مما يؤدي إلى تنفيذ أوامر ضارة أو الوصول غير المصرح به إلى البيانات.',
    severity: 'critical',
    category: 'injection',
    cweId: 'CWE-77',
    remediation: 'استخدام واجهة برمجة تطبيقات آمنة لا تسمح بالمترجم باستخدام المدخلات المباشرة، واستخدام التحقق من صحة المدخلات على جانب الخادم، واستخدام الاستعلامات المعدة مسبقًا.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'injection',
        confidence: 'high'
      },
      {
        tool: 'sqlmap',
        pattern: 'sql injection',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A03:2021 – Injection',
        url: 'https://owasp.org/Top10/A03_2021-Injection/'
      },
      {
        title: 'MITRE CWE-77: Command Injection',
        url: 'https://cwe.mitre.org/data/definitions/77.html'
      }
    ]
  },
  {
    name: 'Insecure Design',
    description: 'التصميم غير الآمن هو فئة واسعة من الضعف تمثل مشاكل في تصميم وهندسة الأمان، وتشمل غياب ضوابط الأمان أو تطبيقها بشكل غير فعال.',
    severity: 'high',
    category: 'design',
    cweId: 'CWE-657',
    remediation: 'إنشاء وصيانة عمليات تطوير آمنة، واستخدام نماذج التهديد، ودمج متطلبات الأمان في قصص المستخدم، وتنفيذ حدود الموارد والضوابط.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'design',
        confidence: 'low'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A04:2021 – Insecure Design',
        url: 'https://owasp.org/Top10/A04_2021-Insecure_Design/'
      },
      {
        title: 'MITRE CWE-657: Violation of Secure Design Principles',
        url: 'https://cwe.mitre.org/data/definitions/657.html'
      }
    ]
  },
  {
    name: 'Security Misconfiguration',
    description: 'تحدث الأخطاء في تكوين الأمان عندما تكون إعدادات الأمان غير آمنة أو غير كاملة أو افتراضية، مما يوفر للمهاجمين وصولاً غير مصرح به إلى بعض بيانات النظام أو وظائفه.',
    severity: 'high',
    category: 'configuration',
    cweId: 'CWE-1027',
    remediation: 'تنفيذ عملية تثبيت آمنة ومتكررة، وإزالة الميزات غير المستخدمة، ومراجعة وتحديث التكوينات، وتنفيذ الأمان المتعمق.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'misconfiguration',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A05:2021 – Security Misconfiguration',
        url: 'https://owasp.org/Top10/A05_2021-Security_Misconfiguration/'
      },
      {
        title: 'MITRE CWE-1027: OWASP Top Ten 2017 Category A6 - Security Misconfiguration',
        url: 'https://cwe.mitre.org/data/definitions/1027.html'
      }
    ]
  },
  {
    name: 'Vulnerable and Outdated Components',
    description: 'تحدث هذه الثغرة عندما تستخدم التطبيقات مكونات أو مكتبات تحتوي على ثغرات معروفة أو قديمة أو غير مدعومة.',
    severity: 'high',
    category: 'components',
    cweId: 'CWE-1026',
    remediation: 'إزالة التبعيات غير المستخدمة والميزات والملفات والوثائق غير الضرورية، ومراقبة إصدارات المكونات باستمرار، والحصول على المكونات من مصادر رسمية، ومراقبة قواعد بيانات الثغرات.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'outdated',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A06:2021 – Vulnerable and Outdated Components',
        url: 'https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/'
      },
      {
        title: 'MITRE CWE-1026: OWASP Top Ten 2017 Category A9 - Using Components with Known Vulnerabilities',
        url: 'https://cwe.mitre.org/data/definitions/1026.html'
      }
    ]
  },
  {
    name: 'Identification and Authentication Failures',
    description: 'تحدث إخفاقات التحقق من الهوية والمصادقة عندما تكون وظائف التطبيق المتعلقة بالمصادقة وإدارة الجلسات منفذة بشكل غير صحيح، مما يسمح للمهاجمين بالتقاط كلمات المرور أو مفاتيح الجلسات أو استغلال عيوب التنفيذ الأخرى لتولي هويات المستخدمين الآخرين.',
    severity: 'high',
    category: 'authentication',
    cweId: 'CWE-287',
    remediation: 'تنفيذ المصادقة متعددة العوامل، وتجنب نشر بيانات اعتماد افتراضية، وتنفيذ ضوابط كلمة المرور القوية، وتنفيذ إدارة جلسة آمنة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'authentication',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A07:2021 – Identification and Authentication Failures',
        url: 'https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/'
      },
      {
        title: 'MITRE CWE-287: Improper Authentication',
        url: 'https://cwe.mitre.org/data/definitions/287.html'
      }
    ]
  },
  {
    name: 'Software and Data Integrity Failures',
    description: 'تحدث إخفاقات سلامة البرامج والبيانات عندما لا تتحقق التطبيقات بشكل صحيح من سلامة التعليمات البرمجية والبيانات، مما قد يؤدي إلى تحديثات غير مصرح بها أو تلف البيانات.',
    severity: 'high',
    category: 'integrity',
    cweId: 'CWE-345',
    remediation: 'استخدام التوقيعات الرقمية للتحقق من سلامة البرامج والبيانات، والتأكد من أن التبعيات والمكونات تأتي من مصادر موثوقة، وتنفيذ عملية مراجعة للتغييرات.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'integrity',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A08:2021 – Software and Data Integrity Failures',
        url: 'https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/'
      },
      {
        title: 'MITRE CWE-345: Insufficient Verification of Data Authenticity',
        url: 'https://cwe.mitre.org/data/definitions/345.html'
      }
    ]
  },
  {
    name: 'Security Logging and Monitoring Failures',
    description: 'تحدث إخفاقات تسجيل وتتبع الأمان عندما لا تقوم التطبيقات بتسجيل الأحداث الأمنية بشكل كافٍ أو مراقبتها، مما يجعل من الصعب اكتشاف الاختراقات أو الاستجابة لها.',
    severity: 'medium',
    category: 'logging',
    cweId: 'CWE-778',
    remediation: 'تنفيذ تسجيل لجميع عمليات تسجيل الدخول والوصول ورفض التحكم في الوصول والتحقق من صحة المدخلات، واستخدام تنسيق موحد للسجلات، وتنفيذ مراقبة وتنبيه فعالة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'logging',
        confidence: 'low'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A09:2021 – Security Logging and Monitoring Failures',
        url: 'https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/'
      },
      {
        title: 'MITRE CWE-778: Insufficient Logging',
        url: 'https://cwe.mitre.org/data/definitions/778.html'
      }
    ]
  },
  {
    name: 'Server-Side Request Forgery (SSRF)',
    description: 'تحدث ثغرات تزوير الطلب من جانب الخادم عندما يقوم تطبيق ويب بجلب مورد عن بُعد دون التحقق من صحة URL المقدم من قبل المستخدم، مما يسمح للمهاجم بإجبار التطبيق على إرسال طلب مخصص إلى وجهة غير متوقعة.',
    severity: 'high',
    category: 'ssrf',
    cweId: 'CWE-918',
    remediation: 'تنفيذ ضوابط الشبكة مثل قوائم السماح للوجهات، وتصفية وتطهير مدخلات المستخدم، وتعطيل إعادة التوجيه HTTP، واستخدام DNS المحلي.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'ssrf',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Top 10 2021 - A10:2021 – Server-Side Request Forgery (SSRF)',
        url: 'https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/'
      },
      {
        title: 'MITRE CWE-918: Server-Side Request Forgery (SSRF)',
        url: 'https://cwe.mitre.org/data/definitions/918.html'
      }
    ]
  }
];

// قائمة إضافية من الثغرات الأمنية الشائعة
const additionalVulnerabilities = [
  {
    name: 'Cross-Site Scripting (XSS)',
    description: 'تحدث ثغرات XSS عندما يقوم تطبيق بتضمين مدخلات المستخدم غير الموثوقة في صفحة ويب جديدة دون التحقق منها أو ترميزها بشكل صحيح، مما يسمح للمهاجمين بتنفيذ نصوص برمجية في متصفح الضحية.',
    severity: 'high',
    category: 'xss',
    cweId: 'CWE-79',
    remediation: 'استخدام ترميز مناسب للسياق عند إدخال بيانات المستخدم في مخرجات HTML، واستخدام أطر عمل حديثة تتجنب XSS تلقائيًا، وتنفيذ سياسة أمان المحتوى (CSP).',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'xss',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP Cross-Site Scripting (XSS)',
        url: 'https://owasp.org/www-community/attacks/xss/'
      },
      {
        title: 'MITRE CWE-79: Improper Neutralization of Input During Web Page Generation',
        url: 'https://cwe.mitre.org/data/definitions/79.html'
      }
    ]
  },
  {
    name: 'SQL Injection',
    description: 'تحدث ثغرات حقن SQL عندما يتم دمج مدخلات المستخدم غير الموثوقة مباشرة في استعلامات SQL، مما يسمح للمهاجمين بتعديل الاستعلام وتنفيذ أوامر SQL ضارة.',
    severity: 'critical',
    category: 'sql_injection',
    cweId: 'CWE-89',
    remediation: 'استخدام الاستعلامات المعدة مسبقًا والاستعلامات المعلمة، وتصفية مدخلات المستخدم، واستخدام أقل امتيازات ممكنة للاتصال بقاعدة البيانات.',
    detectionMethods: [
      {
        tool: 'sqlmap',
        pattern: 'sql injection',
        confidence: 'high'
      },
      {
        tool: 'owasp-zap',
        pattern: 'sql injection',
        confidence: 'high'
      }
    ],
    references: [
      {
        title: 'OWASP SQL Injection',
        url: 'https://owasp.org/www-community/attacks/SQL_Injection'
      },
      {
        title: 'MITRE CWE-89: Improper Neutralization of Special Elements used in an SQL Command',
        url: 'https://cwe.mitre.org/data/definitions/89.html'
      }
    ]
  },
  {
    name: 'Cross-Site Request Forgery (CSRF)',
    description: 'تحدث ثغرات CSRF عندما يمكن للمهاجم خداع مستخدم مصرح له لتنفيذ إجراء على موقع ويب دون علمه أو موافقته.',
    severity: 'medium',
    category: 'csrf',
    cweId: 'CWE-352',
    remediation: 'تنفيذ رموز CSRF في النماذج، والتحقق من رأس Referer، واستخدام SameSite cookie attribute، وطلب إعادة المصادقة للعمليات الحساسة.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'csrf',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Cross-Site Request Forgery (CSRF)',
        url: 'https://owasp.org/www-community/attacks/csrf'
      },
      {
        title: 'MITRE CWE-352: Cross-Site Request Forgery (CSRF)',
        url: 'https://cwe.mitre.org/data/definitions/352.html'
      }
    ]
  },
  {
    name: 'XML External Entity (XXE) Processing',
    description: 'تحدث ثغرات XXE عندما يقوم تطبيق بمعالجة مدخلات XML غير موثوقة تشير إلى كيان خارجي، مما قد يؤدي إلى الكشف عن ملفات داخلية أو تنفيذ أوامر عن بُعد.',
    severity: 'high',
    category: 'xxe',
    cweId: 'CWE-611',
    remediation: 'تعطيل معالجة الكيانات الخارجية والتوجيهات DTD في محللات XML، واستخدام أدوات أبسط مثل JSON، وتحديث مكتبات XML.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'xxe',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP XML External Entity (XXE) Processing',
        url: 'https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing'
      },
      {
        title: 'MITRE CWE-611: Improper Restriction of XML External Entity Reference',
        url: 'https://cwe.mitre.org/data/definitions/611.html'
      }
    ]
  },
  {
    name: 'Insecure Deserialization',
    description: 'تحدث ثغرات إلغاء التسلسل غير الآمن عندما يقوم تطبيق بإلغاء تسلسل بيانات غير موثوقة دون التحقق منها بشكل كافٍ، مما قد يؤدي إلى تنفيذ أوامر عن بُعد.',
    severity: 'high',
    category: 'deserialization',
    cweId: 'CWE-502',
    remediation: 'عدم قبول كائنات مسلسلة من مصادر غير موثوقة، وتنفيذ فحوصات سلامة البيانات، واستخدام تنسيقات بيانات آمنة مثل JSON.',
    detectionMethods: [
      {
        tool: 'owasp-zap',
        pattern: 'deserialization',
        confidence: 'medium'
      }
    ],
    references: [
      {
        title: 'OWASP Deserialization of Untrusted Data',
        url: 'https://owasp.org/www-community/vulnerabilities/Deserialization_of_untrusted_data'
      },
      {
        title: 'MITRE CWE-502: Deserialization of Untrusted Data',
        url: 'https://cwe.mitre.org/data/definitions/502.html'
      }
    ]
  }
];

// دمج قوائم الثغرات
const allVulnerabilities = [...owaspTop10, ...additionalVulnerabilities];

// وظيفة لتعبئة قاعدة البيانات بالثغرات
const seedVulnerabilities = async () => {
  try {
    // حذف جميع الثغرات الموجودة
    await Vulnerability.deleteMany({});
    
    console.log('تم حذف جميع الثغرات الموجودة');
    
    // إضافة الثغرات الجديدة
    await Vulnerability.insertMany(allVulnerabilities);
    
    console.log(`تم إضافة ${allVulnerabilities.length} ثغرة إلى قاعدة البيانات`);
    
    return { success: true, count: allVulnerabilities.length };
  } catch (err) {
    console.error('حدث خطأ أثناء تعبئة قاعدة البيانات بالثغرات:', err);
    return { success: false, error: err.message };
  }
};

// تصدير الوظيفة
module.exports = {
  seedVulnerabilities
};

// تنفيذ التعبئة إذا تم تشغيل الملف مباشرة
if (require.main === module) {
  // التأكد من الاتصال بقاعدة البيانات
  mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/vulnerability_scanner', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(async () => {
    console.log('تم الاتصال بقاعدة البيانات بنجاح');
    
    // تعبئة قاعدة البيانات
    const result = await seedVulnerabilities();
    
    if (result.success) {
      console.log(`تم تعبئة قاعدة البيانات بنجاح. تم إضافة ${result.count} ثغرة.`);
    } else {
      console.error(`فشل تعبئة قاعدة البيانات: ${result.error}`);
    }
    
    // إغلاق الاتصال بقاعدة البيانات
    mongoose.connection.close();
  })
  .catch((err) => {
    console.error('فشل الاتصال بقاعدة البيانات:', err);
  });
}
