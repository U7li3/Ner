const express = require('express');
const router = express.Router();
const ReportGenerator = require('../utils/ReportGenerator');
const path = require('path');
const fs = require('fs');

// إنشاء مولد التقارير
const reportGenerator = new ReportGenerator({
  outputDir: path.join(__dirname, '..', 'reports')
});

// إنشاء تقرير نموذجي للاختبار
router.get('/sample', async (req, res) => {
  try {
    // قراءة بيانات الثغرات من ملف JSON
    const vulnerabilitiesPath = path.join(__dirname, '..', 'data', 'vulnerabilities.json');
    const vulnerabilities = JSON.parse(fs.readFileSync(vulnerabilitiesPath, 'utf8'));
    
    // بيانات فحص نموذجية
    const scanData = {
      id: 'sample-scan-001',
      targetUrl: 'https://example.com',
      scanType: 'comprehensive',
      startTime: new Date(Date.now() - 3600000), // قبل ساعة
      endTime: new Date(),
      status: 'completed'
    };
    
    // إنشاء تقارير بجميع التنسيقات
    const pdfPath = await reportGenerator.generatePdfReport(scanData, vulnerabilities);
    const htmlPath = await reportGenerator.generateHtmlReport(scanData, vulnerabilities);
    const csvPath = await reportGenerator.generateCsvReport(scanData, vulnerabilities);
    const jsonPath = await reportGenerator.generateJsonReport(scanData, vulnerabilities);
    
    res.json({
      message: 'تم إنشاء التقارير النموذجية بنجاح',
      reports: {
        pdf: pdfPath,
        html: htmlPath,
        csv: csvPath,
        json: jsonPath
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء التقارير النموذجية', error: err.message });
  }
});

// تنزيل تقرير نموذجي
router.get('/sample/:format', async (req, res) => {
  try {
    const { format } = req.params;
    
    if (!format || !['pdf', 'html', 'csv', 'json'].includes(format)) {
      return res.status(400).json({ message: 'تنسيق التقرير غير صالح' });
    }
    
    // قراءة بيانات الثغرات من ملف JSON
    const vulnerabilitiesPath = path.join(__dirname, '..', 'data', 'vulnerabilities.json');
    const vulnerabilities = JSON.parse(fs.readFileSync(vulnerabilitiesPath, 'utf8'));
    
    // بيانات فحص نموذجية
    const scanData = {
      id: 'sample-scan-001',
      targetUrl: 'https://example.com',
      scanType: 'comprehensive',
      startTime: new Date(Date.now() - 3600000), // قبل ساعة
      endTime: new Date(),
      status: 'completed'
    };
    
    let reportPath;
    let fileName;
    
    // إنشاء التقرير حسب التنسيق المطلوب
    switch (format) {
      case 'pdf':
        reportPath = await reportGenerator.generatePdfReport(scanData, vulnerabilities);
        fileName = 'sample_vulnerability_report.pdf';
        break;
      case 'html':
        reportPath = await reportGenerator.generateHtmlReport(scanData, vulnerabilities);
        fileName = 'sample_vulnerability_report.html';
        break;
      case 'csv':
        reportPath = await reportGenerator.generateCsvReport(scanData, vulnerabilities);
        fileName = 'sample_vulnerability_report.csv';
        break;
      case 'json':
        reportPath = await reportGenerator.generateJsonReport(scanData, vulnerabilities);
        fileName = 'sample_vulnerability_report.json';
        break;
    }
    
    // إرسال الملف
    res.download(reportPath, fileName, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء التقرير النموذجي', error: err.message });
  }
});

module.exports = router;
