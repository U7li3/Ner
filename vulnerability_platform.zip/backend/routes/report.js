const express = require('express');
const router = express.Router();
const ReportGenerator = require('../utils/ReportGenerator');
const Scan = require('../models/Scan');
const DiscoveredVulnerability = require('../models/DiscoveredVulnerability');
const path = require('path');
const fs = require('fs');
const jwt = require('jsonwebtoken');

// وسيط للتحقق من التوكن
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return res.status(403).json({ message: 'لم يتم توفير توكن المصادقة' });
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'vulnerability_scanner_secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'توكن غير صالح أو منتهي الصلاحية' });
  }
};

// إنشاء مولد التقارير
const reportGenerator = new ReportGenerator({
  outputDir: path.join(__dirname, '..', 'reports')
});

// الحصول على قائمة التقارير
router.get('/', verifyToken, async (req, res) => {
  try {
    // جلب عمليات الفحص المكتملة للمستخدم
    const scans = await Scan.find({ 
      userId: req.user.id,
      status: 'completed'
    })
    .sort({ endTime: -1 })
    .select('targetUrl scanType status summary startTime endTime createdAt');
    
    res.json(scans);
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب قائمة التقارير', error: err.message });
  }
});

// الحصول على تقرير محدد
router.get('/:id', verifyToken, async (req, res) => {
  try {
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    res.json({
      scan,
      vulnerabilities
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب التقرير', error: err.message });
  }
});

// إنشاء تقرير PDF
router.get('/:id/pdf', verifyToken, async (req, res) => {
  try {
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    // إنشاء تقرير PDF
    const pdfPath = await reportGenerator.generatePdfReport(scan, vulnerabilities);
    
    // إرسال الملف
    res.download(pdfPath, `vulnerability_report_${scan._id}.pdf`, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء تقرير PDF', error: err.message });
  }
});

// إنشاء تقرير HTML
router.get('/:id/html', verifyToken, async (req, res) => {
  try {
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    // إنشاء تقرير HTML
    const htmlPath = await reportGenerator.generateHtmlReport(scan, vulnerabilities);
    
    // إرسال الملف
    res.download(htmlPath, `vulnerability_report_${scan._id}.html`, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء تقرير HTML', error: err.message });
  }
});

// إنشاء تقرير CSV
router.get('/:id/csv', verifyToken, async (req, res) => {
  try {
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    // إنشاء تقرير CSV
    const csvPath = await reportGenerator.generateCsvReport(scan, vulnerabilities);
    
    // إرسال الملف
    res.download(csvPath, `vulnerability_report_${scan._id}.csv`, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء تقرير CSV', error: err.message });
  }
});

// إنشاء تقرير JSON
router.get('/:id/json', verifyToken, async (req, res) => {
  try {
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    // إنشاء تقرير JSON
    const jsonPath = await reportGenerator.generateJsonReport(scan, vulnerabilities);
    
    // إرسال الملف
    res.download(jsonPath, `vulnerability_report_${scan._id}.json`, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء تقرير JSON', error: err.message });
  }
});

// إنشاء تقرير بتنسيق محدد
router.post('/:id/generate', verifyToken, async (req, res) => {
  try {
    const { format } = req.body;
    
    if (!format || !['pdf', 'html', 'csv', 'json'].includes(format)) {
      return res.status(400).json({ message: 'تنسيق التقرير غير صالح' });
    }
    
    // جلب عملية الفحص
    const scan = await Scan.findOne({ 
      _id: req.params.id,
      userId: req.user.id,
      status: 'completed'
    });
    
    if (!scan) {
      return res.status(404).json({ message: 'التقرير غير موجود' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    let reportPath;
    let fileName;
    
    // إنشاء التقرير حسب التنسيق المطلوب
    switch (format) {
      case 'pdf':
        reportPath = await reportGenerator.generatePdfReport(scan, vulnerabilities);
        fileName = `vulnerability_report_${scan._id}.pdf`;
        break;
      case 'html':
        reportPath = await reportGenerator.generateHtmlReport(scan, vulnerabilities);
        fileName = `vulnerability_report_${scan._id}.html`;
        break;
      case 'csv':
        reportPath = await reportGenerator.generateCsvReport(scan, vulnerabilities);
        fileName = `vulnerability_report_${scan._id}.csv`;
        break;
      case 'json':
        reportPath = await reportGenerator.generateJsonReport(scan, vulnerabilities);
        fileName = `vulnerability_report_${scan._id}.json`;
        break;
    }
    
    // إرسال الملف
    res.download(reportPath, fileName, (err) => {
      if (err) {
        console.error('خطأ في تنزيل التقرير:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء التقرير', error: err.message });
  }
});

module.exports = router;
