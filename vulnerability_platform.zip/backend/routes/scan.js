const express = require('express');
const router = express.Router();
const Scan = require('../models/Scan');
const DiscoveredVulnerability = require('../models/DiscoveredVulnerability');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { URL } = require('url');

// وسيط للتحقق من التوكن
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return res.status(403).json({ message: 'لم يتم توفير توكن المصادقة' });
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'vulnerability_scanner_secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'توكن غير صالح أو منتهي الصلاحية' });
  }
};

// التحقق من صحة URL
const isValidUrl = (string) => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};

// بدء عملية فحص جديدة
router.post('/', verifyToken, async (req, res) => {
  try {
    const { targetUrl, scanType, configuration } = req.body;
    
    // التحقق من صحة URL
    if (!isValidUrl(targetUrl)) {
      return res.status(400).json({ message: 'عنوان URL غير صالح' });
    }
    
    // إنشاء عملية فحص جديدة
    const newScan = new Scan({
      userId: req.user.id,
      targetUrl,
      scanType: scanType || 'quick',
      status: 'pending',
      configuration: configuration || {
        tools: scanType === 'quick' ? ['owasp-zap'] : 
               scanType === 'comprehensive' ? ['owasp-zap', 'nikto'] : 
               ['owasp-zap'],
        depth: scanType === 'quick' ? 1 : 
               scanType === 'comprehensive' ? 3 : 
               2
      }
    });
    
    await newScan.save();
    
    // بدء عملية الفحص في الخلفية
    startScan(newScan._id);
    
    res.status(201).json({
      message: 'تم بدء عملية الفحص بنجاح',
      scan: {
        id: newScan._id,
        targetUrl: newScan.targetUrl,
        scanType: newScan.scanType,
        status: newScan.status,
        createdAt: newScan.createdAt
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء بدء عملية الفحص', error: err.message });
  }
});

// الحصول على قائمة عمليات الفحص
router.get('/', verifyToken, async (req, res) => {
  try {
    const scans = await Scan.find({ userId: req.user.id })
      .sort({ createdAt: -1 })
      .select('targetUrl scanType status progress summary startTime endTime createdAt');
    
    res.json(scans);
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب عمليات الفحص', error: err.message });
  }
});

// الحصول على تفاصيل عملية فحص محددة
router.get('/:id', verifyToken, async (req, res) => {
  try {
    const scan = await Scan.findOne({ _id: req.params.id, userId: req.user.id });
    
    if (!scan) {
      return res.status(404).json({ message: 'عملية الفحص غير موجودة' });
    }
    
    // جلب الثغرات المكتشفة المرتبطة بعملية الفحص
    const vulnerabilities = await DiscoveredVulnerability.find({ scanId: scan._id });
    
    res.json({
      scan,
      vulnerabilities
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب تفاصيل عملية الفحص', error: err.message });
  }
});

// الحصول على حالة عملية فحص
router.get('/:id/status', verifyToken, async (req, res) => {
  try {
    const scan = await Scan.findOne({ _id: req.params.id, userId: req.user.id })
      .select('status progress startTime endTime');
    
    if (!scan) {
      return res.status(404).json({ message: 'عملية الفحص غير موجودة' });
    }
    
    res.json(scan);
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب حالة عملية الفحص', error: err.message });
  }
});

// حذف عملية فحص
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const scan = await Scan.findOne({ _id: req.params.id, userId: req.user.id });
    
    if (!scan) {
      return res.status(404).json({ message: 'عملية الفحص غير موجودة' });
    }
    
    // حذف الثغرات المكتشفة المرتبطة بعملية الفحص
    await DiscoveredVulnerability.deleteMany({ scanId: scan._id });
    
    // حذف عملية الفحص
    await scan.remove();
    
    res.json({ message: 'تم حذف عملية الفحص بنجاح' });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء حذف عملية الفحص', error: err.message });
  }
});

// وظيفة لبدء عملية الفحص في الخلفية
const startScan = async (scanId) => {
  try {
    // جلب معلومات عملية الفحص
    const scan = await Scan.findById(scanId);
    if (!scan) {
      console.error(`عملية الفحص غير موجودة: ${scanId}`);
      return;
    }
    
    // تحديث حالة عملية الفحص
    scan.status = 'in_progress';
    scan.startTime = new Date();
    scan.progress = 0;
    await scan.save();
    
    // إنشاء دليل للنتائج
    const resultsDir = path.join(__dirname, '..', 'scan_results', scanId.toString());
    if (!fs.existsSync(resultsDir)) {
      fs.mkdirSync(resultsDir, { recursive: true });
    }
    
    // تنفيذ الفحص باستخدام OWASP ZAP
    if (scan.configuration.tools.includes('owasp-zap')) {
      await runZapScan(scan, resultsDir);
    }
    
    // تنفيذ الفحص باستخدام Nikto إذا كان مطلوبًا
    if (scan.configuration.tools.includes('nikto')) {
      await runNiktoScan(scan, resultsDir);
    }
    
    // تحليل النتائج وتحديث قاعدة البيانات
    await analyzeResults(scan, resultsDir);
    
    // تحديث حالة عملية الفحص
    scan.status = 'completed';
    scan.endTime = new Date();
    scan.progress = 100;
    await scan.save();
    
    console.log(`تم اكتمال عملية الفحص: ${scanId}`);
  } catch (err) {
    console.error(`حدث خطأ أثناء تنفيذ عملية الفحص: ${err.message}`);
    
    // تحديث حالة عملية الفحص في حالة الفشل
    try {
      const scan = await Scan.findById(scanId);
      if (scan) {
        scan.status = 'failed';
        scan.endTime = new Date();
        await scan.save();
      }
    } catch (updateErr) {
      console.error(`حدث خطأ أثناء تحديث حالة عملية الفحص: ${updateErr.message}`);
    }
  }
};

// وظيفة لتنفيذ فحص باستخدام OWASP ZAP
const runZapScan = (scan, resultsDir) => {
  return new Promise((resolve, reject) => {
    try {
      console.log(`بدء فحص ZAP للموقع: ${scan.targetUrl}`);
      
      // محاكاة تنفيذ فحص ZAP
      // في التطبيق الفعلي، سيتم استخدام مكتبة python-owasp-zap-v2.4 لتنفيذ الفحص
      
      // تحديث تقدم عملية الفحص
      updateScanProgress(scan._id, 25);
      
      // محاكاة نتائج الفحص
      const zapResults = {
        vulnerabilities: [
          {
            type: 'sql_injection',
            name: 'SQL Injection in Login Form',
            description: 'تم اكتشاف ثغرة حقن SQL في نموذج تسجيل الدخول',
            severity: 'critical',
            location: `${scan.targetUrl}/login`,
            evidence: {
              request: 'POST /login HTTP/1.1\nHost: example.com\n...',
              response: 'HTTP/1.1 200 OK\n...',
              payload: "' OR 1=1 --"
            }
          },
          {
            type: 'xss',
            name: 'Cross-Site Scripting (XSS)',
            description: 'تم اكتشاف ثغرة XSS في صفحة البحث',
            severity: 'high',
            location: `${scan.targetUrl}/search`,
            evidence: {
              request: 'GET /search?q=<script>alert(1)</script> HTTP/1.1\nHost: example.com\n...',
              response: 'HTTP/1.1 200 OK\n...',
              payload: '<script>alert(1)</script>'
            }
          }
        ]
      };
      
      // حفظ نتائج الفحص في ملف
      fs.writeFileSync(path.join(resultsDir, 'zap_results.json'), JSON.stringify(zapResults, null, 2));
      
      // تحديث تقدم عملية الفحص
      updateScanProgress(scan._id, 50);
      
      console.log(`تم اكتمال فحص ZAP للموقع: ${scan.targetUrl}`);
      resolve();
    } catch (err) {
      console.error(`حدث خطأ أثناء تنفيذ فحص ZAP: ${err.message}`);
      reject(err);
    }
  });
};

// وظيفة لتنفيذ فحص باستخدام Nikto
const runNiktoScan = (scan, resultsDir) => {
  return new Promise((resolve, reject) => {
    try {
      console.log(`بدء فحص Nikto للموقع: ${scan.targetUrl}`);
      
      // محاكاة تنفيذ فحص Nikto
      // في التطبيق الفعلي، سيتم استخدام child_process.spawn لتنفيذ الفحص
      
      // تحديث تقدم عملية الفحص
      updateScanProgress(scan._id, 75);
      
      // محاكاة نتائج الفحص
      const niktoResults = {
        vulnerabilities: [
          {
            type: 'security_headers',
            name: 'Missing Security Headers',
            description: 'تم اكتشاف نقص في رؤوس الأمان مثل Content-Security-Policy و X-XSS-Protection',
            severity: 'low',
            location: scan.targetUrl,
            evidence: {
              request: 'GET / HTTP/1.1\nHost: example.com\n...',
              response: 'HTTP/1.1 200 OK\n...',
              payload: null
            }
          }
        ]
      };
      
      // حفظ نتائج الفحص في ملف
      fs.writeFileSync(path.join(resultsDir, 'nikto_results.json'), JSON.stringify(niktoResults, null, 2));
      
      console.log(`تم اكتمال فحص Nikto للموقع: ${scan.targetUrl}`);
      resolve();
    } catch (err) {
      console.error(`حدث خطأ أثناء تنفيذ فحص Nikto: ${err.message}`);
      reject(err);
    }
  });
};

// وظيفة لتحليل نتائج الفحص وتحديث قاعدة البيانات
const analyzeResults = async (scan, resultsDir) => {
  try {
    console.log(`تحليل نتائج الفحص للموقع: ${scan.targetUrl}`);
    
    // قراءة نتائج فحص ZAP
    let zapResults = { vulnerabilities: [] };
    const zapResultsPath = path.join(resultsDir, 'zap_results.json');
    if (fs.existsSync(zapResultsPath)) {
      zapResults = JSON.parse(fs.readFileSync(zapResultsPath, 'utf8'));
    }
    
    // قراءة نتائج فحص Nikto
    let niktoResults = { vulnerabilities: [] };
    const niktoResultsPath = path.join(resultsDir, 'nikto_results.json');
    if (fs.existsSync(niktoResultsPath)) {
      niktoResults = JSON.parse(fs.readFileSync(niktoResultsPath, 'utf8'));
    }
    
    // دمج نتائج الفحص
    const allVulnerabilities = [...zapResults.vulnerabilities, ...niktoResults.vulnerabilities];
    
    // إحصاء الثغرات حسب مستوى الخطورة
    const summary = {
      totalVulnerabilities: allVulnerabilities.length,
      criticalCount: allVulnerabilities.filter(v => v.severity === 'critical').length,
      highCount: allVulnerabilities.filter(v => v.severity === 'high').length,
      mediumCount: allVulnerabilities.filter(v => v.severity === 'medium').length,
      lowCount: allVulnerabilities.filter(v => v.severity === 'low').length,
      infoCount: allVulnerabilities.filter(v => v.severity === 'info').length
    };
    
    // تحديث ملخص عملية الفحص
    scan.summary = summary;
    await scan.save();
    
    // حفظ الثغرات المكتشفة في قاعدة البيانات
    for (const vuln of allVulnerabilities) {
      const newVulnerability = new DiscoveredVulnerability({
        scanId: scan._id,
        vulnerabilityType: vuln.type,
        name: vuln.name,
        description: vuln.description,
        severity: vuln.severity,
        location: {
          url: vuln.location,
          parameter: vuln.evidence?.parameter,
          method: vuln.evidence?.request?.split(' ')[0]
        },
        evidence: {
          request: vuln.evidence?.request,
          response: vuln.evidence?.response,
          payload: vuln.evidence?.payload
        },
        remediation: {
          description: getRemediationForVulnerability(vuln.type)
        },
        references: getReferencesForVulnerability(vuln.type)
      });
      
      await newVulnerability.save();
    }
    
    console.log(`تم تحليل نتائج الفحص للموقع: ${scan.targetUrl}`);
  } catch (err) {
    console.error(`حدث خطأ أثناء تحليل نتائج الفحص: ${err.message}`);
    throw err;
  }
};

// وظيفة لتحديث تقدم عملية الفحص
const updateScanProgress = async (scanId, progress) => {
  try {
    await Scan.findByIdAndUpdate(scanId, { progress });
  } catch (err) {
    console.error(`حدث خطأ أثناء تحديث تقدم عملية الفحص: ${err.message}`);
  }
};

// وظيفة للحصول على توصيات إصلاح الثغرة
const getRemediationForVulnerability = (type) => {
  switch (type) {
    case 'sql_injection':
      return 'استخدم الاستعلامات المعدة مسبقًا وتصفية المدخلات بشكل صحيح لمنع هجمات حقن SQL.';
    case 'xss':
      return 'قم بترميز المخرجات وتصفية المدخلات لمنع هجمات XSS. استخدم سياسة أمان المحتوى (CSP) لتقييد تنفيذ النصوص البرمجية.';
    case 'security_headers':
      return 'قم بإضافة رؤوس الأمان المفقودة مثل Content-Security-Policy و X-XSS-Protection و X-Content-Type-Options.';
    default:
      return 'راجع توثيق OWASP للحصول على إرشادات حول كيفية إصلاح هذه الثغرة.';
  }
};

// وظيفة للحصول على مراجع للثغرة
const getReferencesForVulnerability = (type) => {
  switch (type) {
    case 'sql_injection':
      return [
        { title: 'OWASP SQL Injection', url: 'https://owasp.org/www-community/attacks/SQL_Injection' },
        { title: 'MITRE CWE-89', url: 'https://cwe.mitre.org/data/definitions/89.html' }
      ];
    case 'xss':
      return [
        { title: 'OWASP Cross-Site Scripting', url: 'https://owasp.org/www-community/attacks/xss/' },
        { title: 'MITRE CWE-79', url: 'https://cwe.mitre.org/data/definitions/79.html' }
      ];
    case 'security_headers':
      return [
        { title: 'OWASP Secure Headers Project', url: 'https://owasp.org/www-project-secure-headers/' }
      ];
    default:
      return [
        { title: 'OWASP Top Ten', url: 'https://owasp.org/www-project-top-ten/' }
      ];
  }
};

module.exports = router;
