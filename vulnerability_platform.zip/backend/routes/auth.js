const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// وسيط للتحقق من التوكن
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return res.status(403).json({ message: 'لم يتم توفير توكن المصادقة' });
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'vulnerability_scanner_secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'توكن غير صالح أو منتهي الصلاحية' });
  }
};

// تسجيل مستخدم جديد
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, firstName, lastName } = req.body;
    
    // التحقق من وجود المستخدم
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ message: 'البريد الإلكتروني أو اسم المستخدم مستخدم بالفعل' });
    }
    
    // تشفير كلمة المرور
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // إنشاء مستخدم جديد
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      firstName,
      lastName,
      isVerified: true, // في الإنتاج، يجب تعيينها إلى false وإرسال بريد إلكتروني للتحقق
      verificationToken: Math.random().toString(36).substring(2, 15),
      lastLogin: new Date()
    });
    
    await newUser.save();
    
    // إنشاء توكن JWT
    const token = jwt.sign(
      { id: newUser._id, username: newUser.username, role: newUser.role },
      process.env.JWT_SECRET || 'vulnerability_scanner_secret',
      { expiresIn: '1d' }
    );
    
    res.status(201).json({
      message: 'تم إنشاء المستخدم بنجاح',
      token,
      user: {
        id: newUser._id,
        username: newUser.username,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        role: newUser.role
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء تسجيل المستخدم', error: err.message });
  }
});

// تسجيل الدخول
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'بريد إلكتروني أو كلمة مرور غير صحيحة' });
    }
    
    // التحقق من كلمة المرور
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'بريد إلكتروني أو كلمة مرور غير صحيحة' });
    }
    
    // التحقق من تفعيل الحساب
    if (!user.isVerified) {
      return res.status(401).json({ message: 'الرجاء تفعيل حسابك قبل تسجيل الدخول' });
    }
    
    // تحديث وقت آخر تسجيل دخول
    user.lastLogin = new Date();
    await user.save();
    
    // إنشاء توكن JWT
    const token = jwt.sign(
      { id: user._id, username: user.username, role: user.role },
      process.env.JWT_SECRET || 'vulnerability_scanner_secret',
      { expiresIn: '1d' }
    );
    
    res.json({
      message: 'تم تسجيل الدخول بنجاح',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء تسجيل الدخول', error: err.message });
  }
});

// الحصول على معلومات الملف الشخصي
router.get('/profile', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب معلومات الملف الشخصي', error: err.message });
  }
});

// تحديث معلومات الملف الشخصي
router.put('/profile', verifyToken, async (req, res) => {
  try {
    const { firstName, lastName, email, settings } = req.body;
    
    // التحقق من وجود المستخدم
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    // تحديث المعلومات
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (email && email !== user.email) {
      // التحقق من عدم وجود مستخدم آخر بنفس البريد الإلكتروني
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'البريد الإلكتروني مستخدم بالفعل' });
      }
      user.email = email;
    }
    if (settings) user.settings = { ...user.settings, ...settings };
    
    await user.save();
    
    res.json({
      message: 'تم تحديث الملف الشخصي بنجاح',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        settings: user.settings
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء تحديث الملف الشخصي', error: err.message });
  }
});

// تغيير كلمة المرور
router.post('/change-password', verifyToken, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    // التحقق من وجود المستخدم
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    
    // التحقق من كلمة المرور الحالية
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'كلمة المرور الحالية غير صحيحة' });
    }
    
    // تشفير كلمة المرور الجديدة
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);
    
    // تحديث كلمة المرور
    user.password = hashedPassword;
    await user.save();
    
    res.json({ message: 'تم تغيير كلمة المرور بنجاح' });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء تغيير كلمة المرور', error: err.message });
  }
});

// طلب استعادة كلمة المرور
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    
    // البحث عن المستخدم
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'البريد الإلكتروني غير مسجل' });
    }
    
    // إنشاء توكن لإعادة تعيين كلمة المرور
    const resetToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    
    // تحديث معلومات المستخدم
    user.resetPasswordToken = resetToken;
    user.resetPasswordExpires = Date.now() + 3600000; // صالح لمدة ساعة واحدة
    await user.save();
    
    // في التطبيق الفعلي، يجب إرسال بريد إلكتروني يحتوي على رابط لإعادة تعيين كلمة المرور
    
    res.json({ message: 'تم إرسال تعليمات إعادة تعيين كلمة المرور إلى بريدك الإلكتروني' });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء طلب استعادة كلمة المرور', error: err.message });
  }
});

// إعادة تعيين كلمة المرور
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    
    // البحث عن المستخدم بواسطة التوكن
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: Date.now() }
    });
    
    if (!user) {
      return res.status(400).json({ message: 'توكن إعادة تعيين كلمة المرور غير صالح أو منتهي الصلاحية' });
    }
    
    // تشفير كلمة المرور الجديدة
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);
    
    // تحديث كلمة المرور وإزالة التوكن
    user.password = hashedPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();
    
    res.json({ message: 'تم إعادة تعيين كلمة المرور بنجاح' });
  } catch (err) {
    res.status(500).json({ message: 'حدث خطأ أثناء إعادة تعيين كلمة المرور', error: err.message });
  }
});

module.exports = router;
