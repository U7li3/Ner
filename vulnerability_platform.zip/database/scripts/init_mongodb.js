// سكريبت إعداد قاعدة بيانات MongoDB للمنصة

// إنشاء قاعدة البيانات
// استخدم vulnerability_scanner كاسم لقاعدة البيانات
use vulnerability_scanner;

// إنشاء مجموعة للمستخدمين
db.createCollection('users');

// إنشاء مجموعة لتقارير الفحص
db.createCollection('scan_reports');

// إنشاء مجموعة لتخزين معلومات الثغرات الأمنية
db.createCollection('vulnerabilities');

// إنشاء مجموعة لتخزين سجلات الفحص
db.createCollection('scan_logs');

// إنشاء فهارس للبحث السريع
db.users.createIndex({ "email": 1 }, { unique: true });
db.scan_reports.createIndex({ "userId": 1 });
db.scan_reports.createIndex({ "targetUrl": 1 });
db.vulnerabilities.createIndex({ "scanId": 1 });
db.scan_logs.createIndex({ "scanId": 1 });

// إضافة مستخدم افتراضي للاختبار (يجب تغييره في الإنتاج)
db.users.insertOne({
  username: "admin",
  email: "admin@example.com",
  password: "$2b$10$X7VYVy1Z5Z5Z5Z5Z5Z5Z5OX7VYVy1Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5", // يجب تشفير كلمة المرور في التطبيق الفعلي
  role: "admin",
  createdAt: new Date(),
  updatedAt: new Date()
});

// إضافة بعض أنواع الثغرات الأمنية الشائعة للمرجع
db.vulnerabilities.insertMany([
  {
    name: "SQL Injection",
    description: "ثغرة حقن SQL تسمح للمهاجمين بحقن أوامر SQL ضارة في قاعدة البيانات",
    severity: "high",
    remediation: "استخدام الاستعلامات المعدة مسبقًا وتصفية المدخلات بشكل صحيح",
    references: ["https://owasp.org/www-community/attacks/SQL_Injection"]
  },
  {
    name: "Cross-Site Scripting (XSS)",
    description: "ثغرة XSS تسمح للمهاجمين بحقن نصوص برمجية ضارة تنفذ في متصفح المستخدم",
    severity: "medium",
    remediation: "تصفية وترميز المدخلات والمخرجات بشكل صحيح",
    references: ["https://owasp.org/www-community/attacks/xss/"]
  },
  {
    name: "Cross-Site Request Forgery (CSRF)",
    description: "ثغرة CSRF تسمح للمهاجمين بإجبار المستخدمين على تنفيذ إجراءات غير مرغوب فيها",
    severity: "medium",
    remediation: "استخدام رموز CSRF وفحص رؤوس Referer",
    references: ["https://owasp.org/www-community/attacks/csrf"]
  }
]);

print("تم إعداد قاعدة البيانات بنجاح!");
