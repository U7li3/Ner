import React from 'react';
import { 
  Drawer, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  Divider, 
  Box, 
  Typography,
  Toolbar
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useNavigate, useLocation } from 'react-router-dom';

// أيقونات
import DashboardIcon from '@mui/icons-material/Dashboard';
import SearchIcon from '@mui/icons-material/Search';
import AssessmentIcon from '@mui/icons-material/Assessment';
import SecurityIcon from '@mui/icons-material/Security';
import SettingsIcon from '@mui/icons-material/Settings';
import HelpIcon from '@mui/icons-material/Help';

// عرض الشريط الجانبي
const drawerWidth = 240;

// تنسيق العنصر النشط في القائمة
const StyledListItem = styled(ListItem)(({ theme, active }) => ({
  borderRadius: theme.spacing(1),
  margin: theme.spacing(0.5, 1),
  backgroundColor: active ? alpha(theme.palette.primary.main, 0.1) : 'transparent',
  color: active ? theme.palette.primary.main : theme.palette.text.primary,
  '&:hover': {
    backgroundColor: alpha(theme.palette.primary.main, 0.05),
  },
}));

// استخراج الألوان الشفافة
const alpha = (color, opacity) => {
  return color + Math.round(opacity * 255).toString(16).padStart(2, '0');
};

const Sidebar = ({ open }) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // قائمة العناصر الرئيسية
  const mainMenuItems = [
    { text: 'لوحة التحكم', icon: <DashboardIcon />, path: '/dashboard' },
    { text: 'فحص جديد', icon: <SearchIcon />, path: '/scan/new' },
    { text: 'التقارير', icon: <AssessmentIcon />, path: '/reports' },
    { text: 'قاعدة بيانات الثغرات', icon: <SecurityIcon />, path: '/vulnerabilities' },
  ];
  
  // قائمة العناصر الثانوية
  const secondaryMenuItems = [
    { text: 'الإعدادات', icon: <SettingsIcon />, path: '/settings' },
    { text: 'المساعدة', icon: <HelpIcon />, path: '/help' },
  ];
  
  // التحقق مما إذا كان المسار نشطًا
  const isActive = (path) => {
    return location.pathname === path;
  };
  
  return (
    <Drawer
      variant="persistent"
      open={open}
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
        },
      }}
    >
      <Toolbar /> {/* مساحة لشريط التنقل العلوي */}
      
      <Box sx={{ overflow: 'auto', height: '100%', display: 'flex', flexDirection: 'column' }}>
        <List component="nav" sx={{ p: 1 }}>
          {mainMenuItems.map((item) => (
            <StyledListItem
              button
              key={item.text}
              active={isActive(item.path) ? 1 : 0}
              onClick={() => navigate(item.path)}
            >
              <ListItemIcon sx={{ color: isActive(item.path) ? 'primary.main' : 'inherit' }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.text} />
            </StyledListItem>
          ))}
        </List>
        
        <Divider sx={{ my: 2 }} />
        
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
            آخر الفحوصات
          </Typography>
          <List dense>
            <ListItem button onClick={() => navigate('/scan/123')}>
              <ListItemText 
                primary="example.com" 
                secondary="اكتمل منذ 2 ساعة" 
                primaryTypographyProps={{ variant: 'body2' }}
                secondaryTypographyProps={{ variant: 'caption' }}
              />
            </ListItem>
            <ListItem button onClick={() => navigate('/scan/456')}>
              <ListItemText 
                primary="test-site.org" 
                secondary="اكتمل منذ يوم واحد" 
                primaryTypographyProps={{ variant: 'body2' }}
                secondaryTypographyProps={{ variant: 'caption' }}
              />
            </ListItem>
          </List>
        </Box>
        
        <Box sx={{ flexGrow: 1 }} />
        
        <List component="nav" sx={{ p: 1 }}>
          {secondaryMenuItems.map((item) => (
            <StyledListItem
              button
              key={item.text}
              active={isActive(item.path) ? 1 : 0}
              onClick={() => navigate(item.path)}
            >
              <ListItemIcon sx={{ color: isActive(item.path) ? 'primary.main' : 'inherit' }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.text} />
            </StyledListItem>
          ))}
        </List>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
