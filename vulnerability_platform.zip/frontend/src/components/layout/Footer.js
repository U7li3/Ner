import React from 'react';
import { Box, Typography, Container, Link, Grid } from '@mui/material';
import { styled } from '@mui/material/styles';

// أيقونات
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';

const FooterContainer = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  padding: theme.spacing(6, 0),
  marginTop: 'auto',
}));

const SocialIcon = styled(Link)(({ theme }) => ({
  color: theme.palette.primary.contrastText,
  margin: theme.spacing(0, 1),
  '&:hover': {
    color: theme.palette.secondary.light,
  },
}));

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <FooterContainer>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              منصة كشف الثغرات الأمنية
            </Typography>
            <Typography variant="body2">
              منصة متكاملة لفحص المواقع الإلكترونية واكتشاف الثغرات الأمنية وإعداد تقارير مفصلة عنها.
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              روابط سريعة
            </Typography>
            <Box>
              <Link href="/" color="inherit" display="block" sx={{ mb: 1 }}>
                الصفحة الرئيسية
              </Link>
              <Link href="/scan/new" color="inherit" display="block" sx={{ mb: 1 }}>
                فحص جديد
              </Link>
              <Link href="/reports" color="inherit" display="block" sx={{ mb: 1 }}>
                التقارير
              </Link>
              <Link href="/about" color="inherit" display="block" sx={{ mb: 1 }}>
                حول المنصة
              </Link>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <Typography variant="h6" gutterBottom>
              تواصل معنا
            </Typography>
            <Typography variant="body2" gutterBottom>
              البريد الإلكتروني: info@vulnerability-scanner.com
            </Typography>
            <Box sx={{ mt: 2 }}>
              <SocialIcon href="#" target="_blank" rel="noopener">
                <FacebookIcon />
              </SocialIcon>
              <SocialIcon href="#" target="_blank" rel="noopener">
                <TwitterIcon />
              </SocialIcon>
              <SocialIcon href="#" target="_blank" rel="noopener">
                <LinkedInIcon />
              </SocialIcon>
              <SocialIcon href="#" target="_blank" rel="noopener">
                <GitHubIcon />
              </SocialIcon>
            </Box>
          </Grid>
        </Grid>
        
        <Box sx={{ mt: 5, textAlign: 'center' }}>
          <Typography variant="body2">
            &copy; {currentYear} منصة كشف الثغرات الأمنية. جميع الحقوق محفوظة.
          </Typography>
          <Box sx={{ mt: 1 }}>
            <Link href="/privacy" color="inherit" sx={{ mx: 1 }}>
              سياسة الخصوصية
            </Link>
            <Link href="/terms" color="inherit" sx={{ mx: 1 }}>
              الشروط والأحكام
            </Link>
          </Box>
        </Box>
      </Container>
    </FooterContainer>
  );
};

export default Footer;
