import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Box, CssBaseline } from '@mui/material';

// المكونات المشتركة
import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import Footer from './components/layout/Footer';

// الصفحات
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import NewScanPage from './pages/NewScanPage';
import ScanDetailsPage from './pages/ScanDetailsPage';
import ReportsPage from './pages/ReportsPage';
import VulnerabilityDetailsPage from './pages/VulnerabilityDetailsPage';
import ProfilePage from './pages/ProfilePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <CssBaseline />
      
      {/* شريط التنقل العلوي */}
      <Navbar toggleSidebar={toggleSidebar} />
      
      <Box sx={{ display: 'flex', flexGrow: 1 }}>
        {/* الشريط الجانبي */}
        <Sidebar open={isSidebarOpen} />
        
        {/* المحتوى الرئيسي */}
        <Box component="main" sx={{ flexGrow: 1, p: 3, width: '100%' }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/scan/new" element={<NewScanPage />} />
            <Route path="/scan/:id" element={<ScanDetailsPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/vulnerability/:id" element={<VulnerabilityDetailsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Box>
      </Box>
      
      {/* تذييل الصفحة */}
      <Footer />
    </Box>
  );
}

export default App;
