import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Chip,
  Button,
  Divider,
  LinearProgress,
  Card,
  CardContent,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useParams, useNavigate } from 'react-router-dom';

// أيقونات
import ErrorIcon from '@mui/icons-material/Error';
import WarningIcon from '@mui/icons-material/Warning';
import InfoIcon from '@mui/icons-material/Info';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DescriptionIcon from '@mui/icons-material/Description';
import ShareIcon from '@mui/icons-material/Share';
import DeleteIcon from '@mui/icons-material/Delete';
import DownloadIcon from '@mui/icons-material/Download';
import VisibilityIcon from '@mui/icons-material/Visibility';

// تنسيق ورقة التفاصيل
const DetailPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.spacing(2),
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
  marginBottom: theme.spacing(3),
}));

// تنسيق شريط التقدم
const BorderLinearProgress = styled(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
}));

// مكون لعرض مستوى الخطورة
const SeverityChip = ({ severity }) => {
  const getColor = () => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      case 'low':
        return 'success';
      default:
        return 'default';
    }
  };
  
  const getIcon = () => {
    switch (severity) {
      case 'critical':
        return <ErrorIcon />;
      case 'high':
        return <WarningIcon />;
      case 'medium':
        return <InfoIcon />;
      case 'low':
        return <CheckCircleIcon />;
      default:
        return null;
    }
  };
  
  const getLabel = () => {
    switch (severity) {
      case 'critical':
        return 'حرج';
      case 'high':
        return 'عالي';
      case 'medium':
        return 'متوسط';
      case 'low':
        return 'منخفض';
      default:
        return 'غير معروف';
    }
  };
  
  return (
    <Chip 
      icon={getIcon()} 
      label={getLabel()} 
      color={getColor()} 
      size="small" 
    />
  );
};

const ScanDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // حالة الفحص
  const [scan, setScan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tabValue, setTabValue] = useState(0);
  
  // محاكاة جلب بيانات الفحص من الخلفية
  useEffect(() => {
    // هنا سيتم جلب بيانات الفحص من الخلفية
    setTimeout(() => {
      setScan({
        id: id,
        targetUrl: 'https://example.com',
        scanType: 'comprehensive',
        status: 'completed', // pending, in_progress, completed, failed
        startTime: '2025-04-04T08:30:00Z',
        endTime: '2025-04-04T09:00:00Z',
        progress: 100,
        summary: {
          totalVulnerabilities: 12,
          criticalCount: 2,
          highCount: 3,
          mediumCount: 4,
          lowCount: 3,
          infoCount: 0
        },
        vulnerabilities: [
          {
            id: 'v1',
            name: 'SQL Injection in Login Form',
            type: 'sql_injection',
            severity: 'critical',
            location: 'https://example.com/login',
            description: 'تم اكتشاف ثغرة حقن SQL في نموذج تسجيل الدخول، مما قد يسمح للمهاجمين بالوصول غير المصرح به إلى قاعدة البيانات.'
          },
          {
            id: 'v2',
            name: 'Cross-Site Scripting (XSS)',
            type: 'xss',
            severity: 'high',
            location: 'https://example.com/search',
            description: 'تم اكتشاف ثغرة XSS في صفحة البحث، مما قد يسمح للمهاجمين بحقن نصوص برمجية ضارة تنفذ في متصفح المستخدم.'
          },
          {
            id: 'v3',
            name: 'Insecure Direct Object Reference',
            type: 'idor',
            severity: 'medium',
            location: 'https://example.com/profile',
            description: 'تم اكتشاف ثغرة IDOR في صفحة الملف الشخصي، مما قد يسمح للمستخدمين بالوصول إلى بيانات مستخدمين آخرين.'
          },
          {
            id: 'v4',
            name: 'Missing Security Headers',
            type: 'security_headers',
            severity: 'low',
            location: 'https://example.com',
            description: 'تم اكتشاف نقص في رؤوس الأمان مثل Content-Security-Policy و X-XSS-Protection.'
          },
        ]
      });
      setLoading(false);
    }, 1000);
  }, [id]);
  
  // معالجة تغيير التبويب
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('ar-SA');
  };
  
  // حساب المدة
  const calculateDuration = (startTime, endTime) => {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const durationMs = end - start;
    const minutes = Math.floor(durationMs / 60000);
    const seconds = Math.floor((durationMs % 60000) / 1000);
    return `${minutes} دقيقة و ${seconds} ثانية`;
  };
  
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Typography variant="h4" component="h1" align="center" gutterBottom>
          جاري تحميل تفاصيل الفحص...
        </Typography>
        <LinearProgress />
      </Container>
    );
  }
  
  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1">
          تفاصيل الفحص
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            sx={{ mr: 1 }}
          >
            تصدير التقرير
          </Button>
          <Button 
            variant="contained" 
            color="primary"
            onClick={() => navigate('/scan/new')}
          >
            فحص جديد
          </Button>
        </Box>
      </Box>
      
      {/* معلومات أساسية عن الفحص */}
      <DetailPaper elevation={3}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="subtitle2" color="text.secondary">
              الموقع المستهدف
            </Typography>
            <Typography variant="h6" gutterBottom>
              {scan.targetUrl}
            </Typography>
            
            <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
              نوع الفحص
            </Typography>
            <Typography variant="body1" gutterBottom>
              {scan.scanType === 'quick' ? 'فحص سريع' : 
               scan.scanType === 'comprehensive' ? 'فحص شامل' : 'فحص مخصص'}
            </Typography>
            
            <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
              الحالة
            </Typography>
            <Chip 
              label={
                scan.status === 'pending' ? 'قيد الانتظار' : 
                scan.status === 'in_progress' ? 'قيد التنفيذ' : 
                scan.status === 'completed' ? 'مكتمل' : 'فشل'
              } 
              color={
                scan.status === 'pending' ? 'default' : 
                scan.status === 'in_progress' ? 'info' : 
                scan.status === 'completed' ? 'success' : 'error'
              } 
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Typography variant="subtitle2" color="text.secondary">
              وقت البدء
            </Typography>
            <Typography variant="body1" gutterBottom>
              {formatDate(scan.startTime)}
            </Typography>
            
            <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
              وقت الانتهاء
            </Typography>
            <Typography variant="body1" gutterBottom>
              {scan.status === 'completed' ? formatDate(scan.endTime) : '-'}
            </Typography>
            
            <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
              المدة
            </Typography>
            <Typography variant="body1" gutterBottom>
              {scan.status === 'completed' ? calculateDuration(scan.startTime, scan.endTime) : '-'}
            </Typography>
          </Grid>
          
          {scan.status === 'in_progress' && (
            <Grid item xs={12}>
              <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
                التقدم
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Box sx={{ width: '100%', mr: 1 }}>
                  <BorderLinearProgress variant="determinate" value={scan.progress} />
                </Box>
                <Box sx={{ minWidth: 35 }}>
                  <Typography variant="body2" color="text.secondary">{`${Math.round(scan.progress)}%`}</Typography>
                </Box>
              </Box>
            </Grid>
          )}
        </Grid>
      </DetailPaper>
      
      {/* ملخص النتائج */}
      {scan.status === 'completed' && (
        <DetailPaper elevation={3}>
          <Typography variant="h6" gutterBottom>
            ملخص النتائج
          </Typography>
          
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={6} sm={4} md={2}>
              <Card sx={{ bgcolor: 'error.light', color: 'error.contrastText', textAlign: 'center' }}>
                <CardContent>
                  <Typography variant="h4">{scan.summary.criticalCount}</Typography>
                  <Typography variant="body2">حرج</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={6} sm={4} md={2}>
              <Card sx={{ bgcolor: 'warning.light', color: 'warning.contrastText', textAlign: 'center' }}>
                <CardContent>
                  <Typography variant="h4">{scan.summary.highCount}</Typography>
                  <Typography variant="body2">عالي</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={6} sm={4} md={2}>
              <Card sx={{ bgcolor: 'info.light', color: 'info.contrastText', textAlign: 'center' }}>
                <CardContent>
                  <Typography variant="h4">{scan.summary.mediumCount}</Typography>
                  <Typography variant="body2">متوسط</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={6} sm={4} md={2}>
              <Card sx={{ bgcolor: 'success.light', color: 'success.contrastText', textAlign: 'center' }}>
                <CardContent>
                  <Typography variant="h4">{scan.summary.lowCount}</Typography>
                  <Typography variant="body2">منخفض</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={8} md={4}>
              <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <CardContent sx={{ textAlign: 'center' }}>
                  <Typography variant="h4">{scan.summary.totalVulnerabilities}</Typography>
                  <Typography variant="body2">إجمالي الثغرات</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </DetailPaper>
      )}
      
      {/* تبويبات التفاصيل */}
      {scan.status === 'completed' && (
        <Box sx={{ width: '100%' }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="scan details tabs">
              <Tab label="الثغرات المكتشفة" />
              <Tab label="تفاصيل الفحص" />
              <Tab label="التوصيات" />
            </Tabs>
          </Box>
          
          {/* تبويب الثغرات المكتشفة */}
          <Box role="tabpanel" hidden={tabValue !== 0} sx={{ py: 3 }}>
            {tabValue === 0 && (
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>الثغرة</TableCell>
                      <TableCell>الخطورة</TableCell>
                      <TableCell>الموقع</TableCell>
                      <TableCell>الإجراءات</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {scan.vulnerabilities.map((vulnerability) => (
                      <TableRow key={vulnerability.id}>
                        <TableCell>{vulnerability.name}</TableCell>
                        <TableCell>
                          <SeverityChip severity={vulnerability.severity} />
                        </TableCell>
                        <TableCell>{vulnerability.location}</TableCell>
                        <TableCell>
                          <Tooltip title="عرض التفاصيل">
                            <IconButton 
                              size="small"
                              onClick={() => navigate(`/vulnerability/${vulnerability.id}`)}
                            >
                              <VisibilityIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Box>
          
          {/* تبويب تفاصيل الفحص */}
          <Box role="tabpanel" hidden={tabValue !== 1} sx={{ py: 3 }}>
            {tabValue === 1 && (
              <DetailPaper>
                <Typography variant="subtitle1" gutterBottom>
                  تفاصيل إضافية عن الفحص
                </Typography>
                <Typography variant="body2" paragraph>
                  تم إجراء الفحص باستخدام أدوات متعددة للكشف عن الثغرات الأمنية في الموقع المستهدف. تم فحص الصفحات الرئيسية والفرعية للموقع، وتم اختبار نماذج الإدخال والروابط والملفات المرفقة.
                </Typography>
                
                <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                  الأدوات المستخدمة
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  <Chip label="OWASP ZAP" />
                  <Chip label="Nikto" />
                  <Chip label="SQLMap" />
                </Box>
                
                <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                  نطاق الفحص
                </Typography>
                <Typography variant="body2">
                  تم فحص الموقع بالكامل بما في ذلك جميع الصفحات والروابط المتاحة. تم استثناء المسارات التالية من الفحص:
                </Typography>
                <ul>
                  <li>/admin</li>
                  <li>/api/private</li>
                </ul>
              </DetailPaper>
            )}
          </Box>
          
          {/* تبويب التوصيات */}
          <Box role="tabpanel" hidden={tabValue !== 2} sx={{ py: 3 }}>
            {tabValue === 2 && (
              <DetailPaper>
                <Typography variant="subtitle1" gutterBottom>
                  توصيات عامة
                </Typography>
                <Typography variant="body2" paragraph>
                  بناءً على نتائج الفحص، نوصي باتخاذ الإجراءات التالية لتحسين أمان الموقع:
                </Typography>
                
                <ol>
                  <li>
                    <Typography variant="subtitle2" gutterBottom>
                      معالجة ثغرات حقن SQL
                    </Typography>
                    <Typography variant="body2" paragraph>
                      استخدم الاستعلامات المعدة مسبقًا وتصفية المدخلات بشكل صحيح لمنع هجمات حقن SQL.
                    </Typography>
                  </li>
                  
                  <li>
                    <Typography variant="subtitle2" gutterBottom>
                      معالجة ثغرات XSS
                    </Typography>
                    <Typography variant="body2" paragraph>
                      قم بترميز المخرجات وتصفية المدخلات لمنع هجمات XSS. استخدم سياسة أمان المحتوى (CSP) لتقييد تنفيذ النصوص البرمجية.
                    </Typography>
                  </li>
                  
                  <li>
                    <Typography variant="subtitle2" gutterBottom>
                      تحسين رؤوس الأمان
                    </Typography>
                    <Typography variant="body2" paragraph>
                      قم بإضافة رؤوس الأمان المفقودة مثل Content-Security-Policy و X-XSS-Protection و X-Content-Type-Options.
                    </Typography>
                  </li>
                </ol>
                
                <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                  الخطوات التالية
                </Typography>
                <Typography variant="body2" paragraph>
                  نوصي بإجراء فحص آخر بعد تنفيذ الإصلاحات للتأكد من معالجة جميع الثغرات بشكل صحيح.
                </Typography>
              </DetailPaper>
            )}
          </Box>
        </Box>
      )}
    </Container>
  );
};

export default ScanDetailsPage;
