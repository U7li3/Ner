import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  TextField, 
  Button, 
  Grid, 
  FormControl, 
  FormControlLabel, 
  RadioGroup, 
  Radio, 
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Chip,
  Tooltip,
  CircularProgress
} from '@mui/material';
import { styled } from '@mui/material/styles';

// أيقونات
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import InfoIcon from '@mui/icons-material/Info';
import SecurityIcon from '@mui/icons-material/Security';
import SpeedIcon from '@mui/icons-material/Speed';
import BugReportIcon from '@mui/icons-material/BugReport';

// تنسيق ورقة الفحص
const ScanPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.spacing(2),
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
}));

// تنسيق أيقونات أنواع الفحص
const ScanTypeIcon = styled(Box)(({ theme }) => ({
  fontSize: '2.5rem',
  color: theme.palette.primary.main,
  marginBottom: theme.spacing(1),
}));

const NewScanPage = () => {
  // حالة النموذج
  const [url, setUrl] = useState('');
  const [scanType, setScanType] = useState('quick');
  const [advancedOptions, setAdvancedOptions] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // خيارات متقدمة
  const [selectedTools, setSelectedTools] = useState(['owasp-zap']);
  const [scanDepth, setScanDepth] = useState(2);
  
  // التحقق من صحة URL
  const isValidUrl = (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };
  
  // معالجة تقديم النموذج
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValidUrl(url)) {
      alert('الرجاء إدخال عنوان URL صحيح');
      return;
    }
    
    setLoading(true);
    
    // هنا سيتم إرسال طلب إلى الخلفية لبدء الفحص
    console.log({
      url,
      scanType,
      advancedOptions: advancedOptions ? {
        tools: selectedTools,
        depth: scanDepth
      } : null
    });
    
    // محاكاة الاتصال بالخلفية
    setTimeout(() => {
      setLoading(false);
      // التوجيه إلى صفحة تفاصيل الفحص سيتم هنا
      alert('تم بدء الفحص بنجاح!');
    }, 2000);
  };
  
  // معالجة تغيير أدوات الفحص
  const handleToolChange = (tool) => {
    if (selectedTools.includes(tool)) {
      setSelectedTools(selectedTools.filter(t => t !== tool));
    } else {
      setSelectedTools([...selectedTools, tool]);
    }
  };
  
  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" align="center" gutterBottom>
        فحص جديد
      </Typography>
      <Typography variant="subtitle1" align="center" color="text.secondary" paragraph sx={{ mb: 6 }}>
        أدخل عنوان URL للموقع المراد فحصه واختر نوع الفحص المناسب
      </Typography>
      
      <ScanPaper elevation={3}>
        <form onSubmit={handleSubmit}>
          <TextField
            label="عنوان URL"
            variant="outlined"
            fullWidth
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com"
            required
            sx={{ mb: 4 }}
            helperText="أدخل عنوان URL كاملاً بما في ذلك http:// أو https://"
            error={url !== '' && !isValidUrl(url)}
          />
          
          <Typography variant="h6" gutterBottom>
            نوع الفحص
          </Typography>
          
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={4}>
              <Paper 
                elevation={scanType === 'quick' ? 3 : 1} 
                sx={{ 
                  p: 2, 
                  textAlign: 'center',
                  cursor: 'pointer',
                  border: scanType === 'quick' ? '2px solid' : '1px solid',
                  borderColor: scanType === 'quick' ? 'primary.main' : 'divider',
                  bgcolor: scanType === 'quick' ? 'primary.light' : 'background.paper',
                  color: scanType === 'quick' ? 'primary.contrastText' : 'text.primary',
                  '&:hover': {
                    bgcolor: scanType !== 'quick' ? 'action.hover' : 'primary.light',
                  }
                }}
                onClick={() => setScanType('quick')}
              >
                <ScanTypeIcon>
                  <SpeedIcon fontSize="inherit" />
                </ScanTypeIcon>
                <Typography variant="h6" gutterBottom>
                  فحص سريع
                </Typography>
                <Typography variant="body2">
                  فحص سريع للثغرات الأساسية
                </Typography>
                <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                  ~5 دقائق
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Paper 
                elevation={scanType === 'comprehensive' ? 3 : 1} 
                sx={{ 
                  p: 2, 
                  textAlign: 'center',
                  cursor: 'pointer',
                  border: scanType === 'comprehensive' ? '2px solid' : '1px solid',
                  borderColor: scanType === 'comprehensive' ? 'primary.main' : 'divider',
                  bgcolor: scanType === 'comprehensive' ? 'primary.light' : 'background.paper',
                  color: scanType === 'comprehensive' ? 'primary.contrastText' : 'text.primary',
                  '&:hover': {
                    bgcolor: scanType !== 'comprehensive' ? 'action.hover' : 'primary.light',
                  }
                }}
                onClick={() => setScanType('comprehensive')}
              >
                <ScanTypeIcon>
                  <SecurityIcon fontSize="inherit" />
                </ScanTypeIcon>
                <Typography variant="h6" gutterBottom>
                  فحص شامل
                </Typography>
                <Typography variant="body2">
                  فحص متعمق لجميع أنواع الثغرات
                </Typography>
                <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                  ~30 دقيقة
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Paper 
                elevation={scanType === 'custom' ? 3 : 1} 
                sx={{ 
                  p: 2, 
                  textAlign: 'center',
                  cursor: 'pointer',
                  border: scanType === 'custom' ? '2px solid' : '1px solid',
                  borderColor: scanType === 'custom' ? 'primary.main' : 'divider',
                  bgcolor: scanType === 'custom' ? 'primary.light' : 'background.paper',
                  color: scanType === 'custom' ? 'primary.contrastText' : 'text.primary',
                  '&:hover': {
                    bgcolor: scanType !== 'custom' ? 'action.hover' : 'primary.light',
                  }
                }}
                onClick={() => {
                  setScanType('custom');
                  setAdvancedOptions(true);
                }}
              >
                <ScanTypeIcon>
                  <BugReportIcon fontSize="inherit" />
                </ScanTypeIcon>
                <Typography variant="h6" gutterBottom>
                  فحص مخصص
                </Typography>
                <Typography variant="body2">
                  تخصيص خيارات الفحص حسب احتياجاتك
                </Typography>
                <Typography variant="caption" display="block" sx={{ mt: 1 }}>
                  الوقت يعتمد على الإعدادات
                </Typography>
              </Paper>
            </Grid>
          </Grid>
          
          <Box sx={{ mb: 4 }}>
            <Accordion 
              expanded={advancedOptions} 
              onChange={() => setAdvancedOptions(!advancedOptions)}
              sx={{ boxShadow: 'none', border: '1px solid', borderColor: 'divider' }}
            >
              <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                <Typography variant="subtitle1">خيارات متقدمة</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <Typography variant="subtitle2" gutterBottom>
                      أدوات الفحص
                      <Tooltip title="اختر الأدوات التي ترغب في استخدامها للفحص">
                        <InfoIcon fontSize="small" sx={{ ml: 1, verticalAlign: 'middle', color: 'text.secondary' }} />
                      </Tooltip>
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                      <Chip 
                        label="OWASP ZAP" 
                        color={selectedTools.includes('owasp-zap') ? 'primary' : 'default'} 
                        onClick={() => handleToolChange('owasp-zap')}
                        clickable
                      />
                      <Chip 
                        label="Nikto" 
                        color={selectedTools.includes('nikto') ? 'primary' : 'default'} 
                        onClick={() => handleToolChange('nikto')}
                        clickable
                      />
                      <Chip 
                        label="SQLMap" 
                        color={selectedTools.includes('sqlmap') ? 'primary' : 'default'} 
                        onClick={() => handleToolChange('sqlmap')}
                        clickable
                      />
                      <Chip 
                        label="W3af" 
                        color={selectedTools.includes('w3af') ? 'primary' : 'default'} 
                        onClick={() => handleToolChange('w3af')}
                        clickable
                      />
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12}>
                    <Typography variant="subtitle2" gutterBottom>
                      عمق الفحص
                      <Tooltip title="كلما زاد العمق، زادت شمولية الفحص ولكن سيستغرق وقتًا أطول">
                        <InfoIcon fontSize="small" sx={{ ml: 1, verticalAlign: 'middle', color: 'text.secondary' }} />
                      </Tooltip>
                    </Typography>
                    <FormControl component="fieldset">
                      <RadioGroup
                        row
                        value={scanDepth}
                        onChange={(e) => setScanDepth(parseInt(e.target.value))}
                      >
                        <FormControlLabel value={1} control={<Radio />} label="سطحي" />
                        <FormControlLabel value={2} control={<Radio />} label="متوسط" />
                        <FormControlLabel value={3} control={<Radio />} label="عميق" />
                      </RadioGroup>
                    </FormControl>
                  </Grid>
                </Grid>
              </AccordionDetails>
            </Accordion>
          </Box>
          
          <Divider sx={{ my: 4 }} />
          
          <Box sx={{ textAlign: 'center' }}>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary" 
              size="large"
              disabled={loading || !url || !isValidUrl(url)}
              sx={{ px: 5, py: 1.5, fontWeight: 'bold' }}
            >
              {loading ? (
                <>
                  <CircularProgress size={24} color="inherit" sx={{ mr: 1 }} />
                  جاري بدء الفحص...
                </>
              ) : 'بدء الفحص'}
            </Button>
          </Box>
        </form>
      </ScanPaper>
      
      <Box sx={{ mt: 6 }}>
        <Typography variant="h6" gutterBottom>
          معلومات عن أنواع الفحص
        </Typography>
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle1">فحص سريع</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body2" color="text.secondary">
              الفحص السريع يقوم بإجراء فحص أساسي للموقع للكشف عن الثغرات الأمنية الشائعة والواضحة. يستغرق هذا النوع من الفحص وقتًا قصيرًا (حوالي 5 دقائق) ويناسب الفحص الأولي أو الفحص الدوري السريع. يستخدم هذا الفحص أداة OWASP ZAP بإعدادات سريعة.
            </Typography>
          </AccordionDetails>
        </Accordion>
        
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle1">فحص شامل</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body2" color="text.secondary">
              الفحص الشامل يقوم بإجراء فحص متعمق للموقع للكشف عن مجموعة واسعة من الثغرات الأمنية، بما في ذلك الثغرات الخفية والمعقدة. يستغرق هذا النوع من الفحص وقتًا أطول (حوالي 30 دقيقة) ويناسب الفحص الدوري الشامل أو قبل إطلاق موقع جديد. يستخدم هذا الفحص مجموعة من الأدوات المختلفة مثل OWASP ZAP وNikto وSQLMap.
            </Typography>
          </AccordionDetails>
        </Accordion>
        
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="subtitle1">فحص مخصص</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body2" color="text.secondary">
              الفحص المخصص يتيح لك تحديد الأدوات وعمق الفحص حسب احتياجاتك الخاصة. يمكنك اختيار الأدوات التي ترغب في استخدامها وتحديد عمق الفحص. يناسب هذا النوع من الفحص المستخدمين المتقدمين الذين لديهم معرفة بأنواع الثغرات التي يرغبون في البحث عنها.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Box>
    </Container>
  );
};

export default NewScanPage;
