import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent,
  TextField,
  Button,
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Switch,
  FormControlLabel
} from '@mui/material';
import { styled } from '@mui/material/styles';

// أيقونات
import DashboardIcon from '@mui/icons-material/Dashboard';
import SecurityIcon from '@mui/icons-material/Security';
import NotificationsIcon from '@mui/icons-material/Notifications';
import LanguageIcon from '@mui/icons-material/Language';
import LockIcon from '@mui/icons-material/Lock';
import HistoryIcon from '@mui/icons-material/History';

// تنسيق ورقة الملف الشخصي
const ProfilePaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.spacing(2),
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
  marginBottom: theme.spacing(3),
}));

const ProfilePage = () => {
  // بيانات المستخدم (ستأتي من الخلفية في التطبيق الفعلي)
  const [user, setUser] = useState({
    username: 'user123',
    email: 'user@example.com',
    firstName: 'محمد',
    lastName: 'أحمد',
    role: 'user',
    createdAt: '2025-01-15T10:30:00Z',
    lastLogin: '2025-04-04T08:00:00Z',
    settings: {
      notifications: {
        email: true,
        browser: true
      },
      theme: 'light',
      language: 'ar'
    }
  });
  
  // حالة النموذج
  const [formData, setFormData] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // حالة الإعدادات
  const [settings, setSettings] = useState(user.settings);
  
  // معالجة تغيير حقول النموذج
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // معالجة تغيير الإعدادات
  const handleSettingChange = (section, setting) => (e) => {
    setSettings({
      ...settings,
      [section]: {
        ...settings[section],
        [setting]: e.target.checked
      }
    });
  };
  
  // معالجة تقديم نموذج المعلومات الشخصية
  const handleProfileSubmit = (e) => {
    e.preventDefault();
    // هنا سيتم إرسال البيانات إلى الخلفية لتحديثها
    console.log('تحديث المعلومات الشخصية:', formData);
    alert('تم تحديث المعلومات الشخصية بنجاح!');
  };
  
  // معالجة تقديم نموذج تغيير كلمة المرور
  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (formData.newPassword !== formData.confirmPassword) {
      alert('كلمة المرور الجديدة وتأكيدها غير متطابقين');
      return;
    }
    // هنا سيتم إرسال البيانات إلى الخلفية لتحديث كلمة المرور
    console.log('تغيير كلمة المرور:', {
      currentPassword: formData.currentPassword,
      newPassword: formData.newPassword
    });
    alert('تم تغيير كلمة المرور بنجاح!');
    setFormData({
      ...formData,
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };
  
  // معالجة تقديم نموذج الإعدادات
  const handleSettingsSubmit = (e) => {
    e.preventDefault();
    // هنا سيتم إرسال البيانات إلى الخلفية لتحديث الإعدادات
    console.log('تحديث الإعدادات:', settings);
    alert('تم تحديث الإعدادات بنجاح!');
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('ar-SA');
  };
  
  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        الملف الشخصي
      </Typography>
      
      <Grid container spacing={3}>
        {/* القسم الأيسر - معلومات المستخدم والإعدادات */}
        <Grid item xs={12} md={4}>
          <ProfilePaper elevation={3}>
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 3 }}>
              <Avatar 
                sx={{ 
                  width: 100, 
                  height: 100, 
                  bgcolor: 'primary.main',
                  fontSize: '2.5rem',
                  mb: 2
                }}
              >
                {user.firstName.charAt(0)}{user.lastName.charAt(0)}
              </Avatar>
              <Typography variant="h5" gutterBottom>
                {user.firstName} {user.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {user.email}
              </Typography>
              <Chip 
                label={user.role === 'admin' ? 'مدير' : 'مستخدم'} 
                color={user.role === 'admin' ? 'primary' : 'default'} 
                size="small"
                sx={{ mt: 1 }}
              />
            </Box>
            
            <Divider sx={{ my: 2 }} />
            
            <List dense>
              <ListItem>
                <ListItemIcon>
                  <DashboardIcon fontSize="small" />
                </ListItemIcon>
                <ListItemText 
                  primary="تاريخ الانضمام" 
                  secondary={formatDate(user.createdAt)} 
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <HistoryIcon fontSize="small" />
                </ListItemIcon>
                <ListItemText 
                  primary="آخر تسجيل دخول" 
                  secondary={formatDate(user.lastLogin)} 
                />
              </ListItem>
            </List>
            
            <Divider sx={{ my: 2 }} />
            
            <Typography variant="subtitle1" gutterBottom>
              إحصائيات سريعة
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Card sx={{ textAlign: 'center' }}>
                  <CardContent>
                    <Typography variant="h4">12</Typography>
                    <Typography variant="body2">عمليات الفحص</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={6}>
                <Card sx={{ textAlign: 'center' }}>
                  <CardContent>
                    <Typography variant="h4">48</Typography>
                    <Typography variant="body2">الثغرات المكتشفة</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </ProfilePaper>
        </Grid>
        
        {/* القسم الأيمن - النماذج */}
        <Grid item xs={12} md={8}>
          {/* نموذج المعلومات الشخصية */}
          <ProfilePaper elevation={3}>
            <Typography variant="h6" gutterBottom>
              المعلومات الشخصية
            </Typography>
            <form onSubmit={handleProfileSubmit}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="الاسم الأول"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    fullWidth
                    margin="normal"
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="الاسم الأخير"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    fullWidth
                    margin="normal"
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    label="البريد الإلكتروني"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    fullWidth
                    margin="normal"
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                    <Button type="submit" variant="contained" color="primary">
                      حفظ التغييرات
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </form>
          </ProfilePaper>
          
          {/* نموذج تغيير كلمة المرور */}
          <ProfilePaper elevation={3}>
            <Typography variant="h6" gutterBottom>
              تغيير كلمة المرور
            </Typography>
            <form onSubmit={handlePasswordSubmit}>
              <TextField
                label="كلمة المرور الحالية"
                name="currentPassword"
                type="password"
                value={formData.currentPassword}
                onChange={handleInputChange}
                fullWidth
                margin="normal"
                variant="outlined"
                required
              />
              <TextField
                label="كلمة المرور الجديدة"
                name="newPassword"
                type="password"
                value={formData.newPassword}
                onChange={handleInputChange}
                fullWidth
                margin="normal"
                variant="outlined"
                required
              />
              <TextField
                label="تأكيد كلمة المرور الجديدة"
                name="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                fullWidth
                margin="normal"
                variant="outlined"
                required
                error={formData.newPassword !== formData.confirmPassword && formData.confirmPassword !== ''}
                helperText={formData.newPassword !== formData.confirmPassword && formData.confirmPassword !== '' ? 'كلمة المرور غير متطابقة' : ''}
              />
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                <Button type="submit" variant="contained" color="primary">
                  تغيير كلمة المرور
                </Button>
              </Box>
            </form>
          </ProfilePaper>
          
          {/* نموذج الإعدادات */}
          <ProfilePaper elevation={3}>
            <Typography variant="h6" gutterBottom>
              الإعدادات
            </Typography>
            <form onSubmit={handleSettingsSubmit}>
              <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
                الإشعارات
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.notifications.email}
                    onChange={handleSettingChange('notifications', 'email')}
                    color="primary"
                  />
                }
                label="إشعارات البريد الإلكتروني"
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.notifications.browser}
                    onChange={handleSettingChange('notifications', 'browser')}
                    color="primary"
                  />
                }
                label="إشعارات المتصفح"
              />
              
              <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
                اللغة والمظهر
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.theme === 'dark'}
                    onChange={(e) => setSettings({
                      ...settings,
                      theme: e.target.checked ? 'dark' : 'light'
                    })}
                    color="primary"
                  />
                }
                label="الوضع الداكن"
              />
              
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                <Button type="submit" variant="contained" color="primary">
                  حفظ الإعدادات
                </Button>
              </Box>
            </form>
          </ProfilePaper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ProfilePage;
