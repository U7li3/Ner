import React from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';

// أيقونات
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SecurityIcon from '@mui/icons-material/Security';
import SpeedIcon from '@mui/icons-material/Speed';
import AssessmentIcon from '@mui/icons-material/Assessment';
import BugReportIcon from '@mui/icons-material/BugReport';

// تنسيق القسم الرئيسي
const HeroSection = styled(Box)(({ theme }) => ({
  background: `linear-gradient(45deg, ${theme.palette.primary.main} 30%, ${theme.palette.primary.dark} 90%)`,
  color: theme.palette.primary.contrastText,
  padding: theme.spacing(10, 0, 8),
  textAlign: 'center',
}));

// تنسيق أيقونات الميزات
const FeatureIcon = styled(Box)(({ theme }) => ({
  fontSize: '3rem',
  color: theme.palette.primary.main,
  marginBottom: theme.spacing(2),
}));

const HomePage = () => {
  const navigate = useNavigate();
  
  // الأسئلة الشائعة
  const faqs = [
    {
      question: 'ما هي منصة كشف الثغرات الأمنية؟',
      answer: 'منصة كشف الثغرات الأمنية هي أداة متكاملة تساعدك على فحص المواقع الإلكترونية للكشف عن الثغرات الأمنية المحتملة، وتقديم تقارير مفصلة عنها مع توصيات للإصلاح.'
    },
    {
      question: 'كيف تعمل المنصة؟',
      answer: 'تعمل المنصة عن طريق إدخال عنوان URL للموقع المراد فحصه، ثم تقوم بتنفيذ مجموعة من الاختبارات الأمنية باستخدام أدوات متخصصة مثل OWASP ZAP وغيرها، وتحليل النتائج وتقديمها في تقرير شامل.'
    },
    {
      question: 'هل استخدام المنصة آمن؟',
      answer: 'نعم، المنصة مصممة لإجراء فحوصات غير ضارة للمواقع. ومع ذلك، يجب استخدامها فقط على المواقع التي تملك تصريحًا لفحصها، حيث أن فحص مواقع الآخرين دون إذن قد يكون غير قانوني.'
    },
    {
      question: 'ما هي أنواع الثغرات التي يمكن للمنصة اكتشافها؟',
      answer: 'يمكن للمنصة اكتشاف مجموعة واسعة من الثغرات الأمنية، بما في ذلك حقن SQL، وثغرات XSS، وثغرات CSRF، ومشاكل التكوين الخاطئ للخوادم، وثغرات التوثيق، وغيرها الكثير.'
    },
  ];
  
  return (
    <>
      {/* القسم الرئيسي */}
      <HeroSection>
        <Container maxWidth="md">
          <Typography variant="h2" component="h1" gutterBottom>
            اكتشف وأصلح الثغرات الأمنية في موقعك
          </Typography>
          <Typography variant="h5" component="p" paragraph>
            منصة متكاملة لفحص المواقع الإلكترونية واكتشاف الثغرات الأمنية وإعداد تقارير مفصلة عنها
          </Typography>
          <Button 
            variant="contained" 
            color="secondary" 
            size="large"
            onClick={() => navigate('/scan/new')}
            sx={{ mt: 3, fontWeight: 'bold', px: 4, py: 1.5 }}
          >
            ابدأ الفحص الآن
          </Button>
        </Container>
      </HeroSection>
      
      {/* قسم الميزات */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography variant="h4" component="h2" align="center" gutterBottom>
          مميزات المنصة
        </Typography>
        <Typography variant="subtitle1" align="center" color="text.secondary" paragraph sx={{ mb: 6 }}>
          اكتشف كيف يمكن لمنصتنا مساعدتك في تأمين موقعك الإلكتروني
        </Typography>
        
        <Grid container spacing={4}>
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <FeatureIcon>
                <SecurityIcon fontSize="inherit" />
              </FeatureIcon>
              <Typography variant="h6" gutterBottom>
                فحص شامل
              </Typography>
              <Typography variant="body2" color="text.secondary">
                فحص شامل للموقع باستخدام مجموعة متنوعة من أدوات الأمان المتقدمة
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <FeatureIcon>
                <SpeedIcon fontSize="inherit" />
              </FeatureIcon>
              <Typography variant="h6" gutterBottom>
                سرعة في الأداء
              </Typography>
              <Typography variant="body2" color="text.secondary">
                نتائج سريعة وفعالة مع خيارات متعددة لعمق وسرعة الفحص
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <FeatureIcon>
                <AssessmentIcon fontSize="inherit" />
              </FeatureIcon>
              <Typography variant="h6" gutterBottom>
                تقارير مفصلة
              </Typography>
              <Typography variant="body2" color="text.secondary">
                تقارير شاملة ومفصلة مع توصيات لإصلاح الثغرات المكتشفة
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <FeatureIcon>
                <BugReportIcon fontSize="inherit" />
              </FeatureIcon>
              <Typography variant="h6" gutterBottom>
                قاعدة بيانات الثغرات
              </Typography>
              <Typography variant="body2" color="text.secondary">
                قاعدة بيانات محدثة باستمرار لأحدث الثغرات الأمنية وطرق استغلالها
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Container>
      
      {/* قسم كيفية العمل */}
      <Box sx={{ bgcolor: 'background.paper', py: 8 }}>
        <Container maxWidth="lg">
          <Typography variant="h4" component="h2" align="center" gutterBottom>
            كيف تعمل المنصة
          </Typography>
          <Typography variant="subtitle1" align="center" color="text.secondary" paragraph sx={{ mb: 6 }}>
            خطوات بسيطة للبدء في فحص موقعك الإلكتروني
          </Typography>
          
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="div"
                  sx={{ height: 140, bgcolor: 'primary.light', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  <Typography variant="h1" color="primary.contrastText">1</Typography>
                </CardMedia>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    أدخل عنوان الموقع
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    قم بإدخال عنوان URL للموقع المراد فحصه واختر نوع الفحص المناسب (سريع، شامل، مخصص)
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="div"
                  sx={{ height: 140, bgcolor: 'primary.light', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  <Typography variant="h1" color="primary.contrastText">2</Typography>
                </CardMedia>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    انتظر اكتمال الفحص
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    تقوم المنصة بتنفيذ مجموعة من الاختبارات الأمنية على الموقع وتحليل النتائج بشكل تلقائي
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="div"
                  sx={{ height: 140, bgcolor: 'primary.light', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  <Typography variant="h1" color="primary.contrastText">3</Typography>
                </CardMedia>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    استعرض التقرير
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    احصل على تقرير مفصل يوضح الثغرات المكتشفة وتصنيفها حسب مستوى الخطورة مع توصيات للإصلاح
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Container>
      </Box>
      
      {/* قسم الأسئلة الشائعة */}
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Typography variant="h4" component="h2" align="center" gutterBottom>
          الأسئلة الشائعة
        </Typography>
        <Typography variant="subtitle1" align="center" color="text.secondary" paragraph sx={{ mb: 6 }}>
          إجابات على الأسئلة الأكثر شيوعًا حول منصتنا
        </Typography>
        
        {faqs.map((faq, index) => (
          <Accordion key={index} sx={{ mb: 2 }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="subtitle1">{faq.question}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography variant="body2" color="text.secondary">
                {faq.answer}
              </Typography>
            </AccordionDetails>
          </Accordion>
        ))}
      </Container>
      
      {/* قسم الدعوة للعمل */}
      <Box sx={{ bgcolor: 'primary.main', color: 'primary.contrastText', py: 6, textAlign: 'center' }}>
        <Container maxWidth="md">
          <Typography variant="h4" component="h2" gutterBottom>
            جاهز لتأمين موقعك الإلكتروني؟
          </Typography>
          <Typography variant="subtitle1" paragraph sx={{ mb: 4 }}>
            ابدأ الآن في فحص موقعك واكتشاف الثغرات الأمنية قبل أن يستغلها المهاجمون
          </Typography>
          <Button 
            variant="contained" 
            color="secondary" 
            size="large"
            onClick={() => navigate('/register')}
            sx={{ mx: 1, fontWeight: 'bold' }}
          >
            إنشاء حساب
          </Button>
          <Button 
            variant="outlined" 
            color="inherit" 
            size="large"
            onClick={() => navigate('/scan/new')}
            sx={{ mx: 1, fontWeight: 'bold' }}
          >
            ابدأ الفحص
          </Button>
        </Container>
      </Box>
    </>
  );
};

export default HomePage;
